import pandas as pd
import datetime
import os
import shutil
import openpyxl
import win32com.client
from pathlib import Path
from unidecode import unidecode
from typing import Optional, Tuple, Literal

# ============================================================================
# FUNCIONES MISCELÁNEAS Y UTILIDADES GENERALES
# ============================================================================

def estandariza_nombre_columnas_dataframe(data_frame: pd.DataFrame) -> pd.DataFrame:
    """
    Estandariza los nombres de las columnas de un DataFrame.
    
    Convierte los nombres de columnas a un formato estándar: sin acentos,
    espacios reemplazados por guiones bajos, y todo en mayúsculas.
    
    Args:
        data_frame: DataFrame de pandas al cual estandarizar los nombres de columnas
        
    Returns:
        pd.DataFrame: DataFrame con nombres de columnas estandarizados
        
    Example:
        >>> import pandas as pd
        >>> 
        >>> # DataFrame con nombres problemáticos
        >>> df = pd.DataFrame({
        ...     'Nombre Completo': ['Juan', 'María'],
        ...     'Año de Nacimiento': [1990, 1985],
        ...     'País de Residencia': ['Chile', 'Argentina']
        ... })
        >>> 
        >>> # Estandarizar nombres
        >>> df_limpio = estandariza_nombre_columnas_dataframe(df)
        >>> print(df_limpio.columns.tolist())
        >>> # ['NOMBRE_COMPLETO', 'ANO_DE_NACIMIENTO', 'PAIS_DE_RESIDENCIA']
        >>> 
        >>> # Verificar que los datos se mantienen
        >>> print(df_limpio.head())
        
    Note:
        - Elimina acentos y caracteres especiales usando unidecode
        - Reemplaza espacios con guiones bajos (_)
        - Convierte todo a mayúsculas para consistencia
        - Los datos del DataFrame no se modifican, solo los nombres de columnas
        - Útil para preparar datos para bases de datos o sistemas que requieren
          nombres de columna sin caracteres especiales
    """
    data_frame.columns = [unidecode(col).replace(" ", "_").upper() for col in data_frame.columns]
    return data_frame

def copia_archivo_en_ruta(ruta_archivo_org: str,
                          ruta_copia: str,
                          nombre_copia: str,
                          agregar_fecha: bool) -> None:
    """
    Copia un archivo a una nueva ubicación con opción de agregar timestamp al nombre.
    
    Permite copiar archivos a una nueva ubicación, opcionalmente agregando
    la fecha y hora actual al nombre del archivo para evitar sobrescritura.
    
    Args:
        ruta_archivo_org: Ruta completa del archivo original a copiar
        ruta_copia: Directorio de destino donde se copiará el archivo
        nombre_copia: Nombre base para el archivo copiado (sin extensión)
        agregar_fecha: Si True, agrega timestamp al nombre del archivo
        
    Returns:
        None: La función no retorna valores, imprime el resultado en consola
        
    Raises:
        FileNotFoundError: Si el archivo original no existe
        PermissionError: Si no hay permisos para escribir en el destino
        
    Example:
        >>> # Copia simple sin timestamp
        >>> copia_archivo_en_ruta(
        ...     ruta_archivo_org=r"C:\datos\reporte.xlsx",
        ...     ruta_copia=r"C:\backups",
        ...     nombre_copia="reporte_backup.xlsx",
        ...     agregar_fecha=False
        ... )
        >>> # Resultado: C:\backups\reporte_backup.xlsx
        >>> 
        >>> # Copia con timestamp automático
        >>> copia_archivo_en_ruta(
        ...     ruta_archivo_org=r"C:\datos\reporte.xlsx",
        ...     ruta_copia=r"C:\backups",
        ...     nombre_copia="reporte_backup.xlsx", 
        ...     agregar_fecha=True
        ... )
        >>> # Resultado: C:\backups\20231114_15.30_reporte_backup.xlsx
        >>> 
        >>> # Para múltiples archivos
        >>> archivos = ["reporte1.xlsx", "reporte2.xlsx"]
        >>> for archivo in archivos:
        ...     copia_archivo_en_ruta(archivo, r"C:\backups", f"backup_{archivo}", True)
        
    Note:
        - Crea automáticamente el directorio destino si no existe
        - El timestamp tiene formato YYYYMMDD_HH.MM para ordenamiento cronológico
        - Preserva la extensión del archivo original si no se especifica en nombre_copia
        - Útil para respaldos automáticos y versionado de archivos
    """
    # Crear directorio de destino si no existe
    Path(ruta_copia).mkdir(parents=True, exist_ok=True)
    
    if agregar_fecha:
        fecha_actual = datetime.datetime.now().strftime("%Y%m%d_%H.%M")
        nuevo_nombre_archivo = f"{fecha_actual}_{nombre_copia}"
    else:
        nuevo_nombre_archivo = nombre_copia
        
    ruta_archivo_copia_completa = Path(ruta_copia) / nuevo_nombre_archivo
    
    try:
        shutil.copy(ruta_archivo_org, ruta_archivo_copia_completa)
        print(f"Archivo copiado exitosamente: {ruta_archivo_copia_completa}")
    except FileNotFoundError:
        print(f"Error: Archivo origen no encontrado: {ruta_archivo_org}")
        raise
    except PermissionError:
        print(f"Error: Sin permisos para escribir en: {ruta_copia}")
        raise

def ejecutar_macro_excel(ruta_archivo: str, nombre_macro: str) -> None:
    """
    Ejecuta una macro VBA en un archivo Excel .xlsm de forma segura.
    
    Crea una instancia independiente de Excel para ejecutar la macro sin afectar
    otros libros abiertos. Incluye validaciones y manejo robusto de errores.
    
    Args:
        ruta_archivo: Ruta completa del archivo Excel (.xlsm) que contiene la macro
        nombre_macro: Nombre de la macro a ejecutar. Puede ser 'MiMacro' o 'Modulo1.MiMacro'
        
    Returns:
        None: La función no retorna valores, imprime el resultado en consola
        
    Raises:
        FileNotFoundError: Si el archivo Excel no existe
        Exception: Para otros errores durante la ejecución de la macro
        
    Example:
        >>> # Ejecutar macro simple
        >>> ejecutar_macro_excel(
        ...     ruta_archivo=r"C:\reportes\reporte_mensual.xlsm",
        ...     nombre_macro="ActualizarDatos"
        ... )
        >>> 
        >>> # Ejecutar macro con modulo especifico
        >>> ejecutar_macro_excel(
        ...     ruta_archivo=r"C:\\macros\\utilidades.xlsm", 
        ...     nombre_macro="Modulo1.ProcesarReporte"
        ... )
        >>> 
        >>> # En un bucle para múltiples archivos
        >>> archivos_macro = [
        ...     r"C:\reportes\reporte1.xlsm",
        ...     r"C:\reportes\reporte2.xlsm"
        ... ]
        >>> for archivo in archivos_macro:
        ...     ejecutar_macro_excel(archivo, "ProcesarDatos")
        
    Note:
        - Usa DispatchEx para crear nueva instancia de Excel (no reutiliza existentes)
        - Excel permanece invisible durante la ejecución
        - Desactiva alertas automáticamente para ejecución desatendida
        - Guarda automáticamente los cambios después de ejecutar la macro
        - Cierra solo la instancia creada, no afecta otras instancias de Excel
        - El formato de macro incluye el nombre del libro para mayor robustez
    """
    # Validar que el archivo existe antes de intentar abrirlo
    if not os.path.exists(ruta_archivo):
        print(f"Error: El archivo no se encuentra en la ruta: {ruta_archivo}")
        return

    excel = None  # Inicializar para el bloque finally
    try:
        # Usar DispatchEx para forzar creación de NUEVA instancia de Excel
        excel = win32com.client.DispatchEx("Excel.Application")
        excel.Visible = False  # Mantener invisible
        excel.DisplayAlerts = False  # Desactivar alertas de Excel

        # Abrir el libro de trabajo en esta nueva instancia
        libro = excel.Workbooks.Open(ruta_archivo)

        # Ejecutar la macro con formato robusto que incluye el nombre del libro
        macro_completa = f"'{os.path.basename(ruta_archivo)}'!{nombre_macro}"
        excel.Application.Run(macro_completa)

        # Cerrar el libro guardando cambios
        libro.Close(SaveChanges=True)
        print(f"Macro '{nombre_macro}' ejecutada y libro guardado exitosamente.")

    except FileNotFoundError:
        print(f"Error: Archivo no encontrado: {ruta_archivo}")
        raise
    except Exception as e:
        print(f"Error al ejecutar la macro '{nombre_macro}': {e}")
        raise

    finally:
        # Cerrar la instancia de Excel que creamos
        if excel:
            excel.Quit()

def limpiar_hoja_xlsm(ruta_archivo: str,
                      nombre_hoja: str,
                      rango_filas: Optional[Tuple[int, int]] = None,
                      rango_columnas: Optional[Tuple[int, int]] = None,
                      rango_celdas: Optional[Tuple[int, int, int, int]] = None,
                      modo: Literal["filas", "columnas", "celdas", "todo"] = "todo") -> None:
    """
    Limpia contenido de una hoja Excel .xlsm según diferentes modos de operación.
    
    Permite borrar selectivamente filas, columnas, celdas específicas o todo
    el contenido de una hoja, preservando las macros VBA del archivo.
    
    Args:
        ruta_archivo: Ruta al archivo Excel .xlsm
        nombre_hoja: Nombre de la hoja a limpiar
        rango_filas: Tupla (fila_inicio, fila_fin) para borrar filas específicas
        rango_columnas: Tupla (col_inicio, col_fin) para borrar columnas específicas  
        rango_celdas: Tupla (fila_inicio, fila_fin, col_inicio, col_fin) para celdas específicas
        modo: Tipo de limpieza a realizar: "filas", "columnas", "celdas" o "todo"
        
    Returns:
        None: La función no retorna valores, imprime el resultado en consola
        
    Raises:
        FileNotFoundError: Si el archivo Excel no existe
        Exception: Para otros errores durante la operación
        
    Example:
        >>> # Limpiar toda la hoja
        >>> limpiar_hoja_xlsm(
        ...     ruta_archivo=r"C:\reportes\datos.xlsm",
        ...     nombre_hoja="Datos", 
        ...     modo="todo"
        ... )
        >>> 
        >>> # Borrar filas específicas (filas 5 a 10)
        >>> limpiar_hoja_xlsm(
        ...     ruta_archivo=r"C:\reportes\datos.xlsm",
        ...     nombre_hoja="Datos",
        ...     rango_filas=(5, 10),
        ...     modo="filas"
        ... )
        >>> 
        >>> # Borrar columnas específicas (columnas A a C)
        >>> limpiar_hoja_xlsm(
        ...     ruta_archivo=r"C:\reportes\datos.xlsm", 
        ...     nombre_hoja="Datos",
        ...     rango_columnas=(1, 3),  # A=1, B=2, C=3
        ...     modo="columnas"
        ... )
        >>> 
        >>> # Limpiar área específica (A1:C5)
        >>> limpiar_hoja_xlsm(
        ...     ruta_archivo=r"C:\reportes\datos.xlsm",
        ...     nombre_hoja="Datos", 
        ...     rango_celdas=(1, 5, 1, 3),  # filas 1-5, columnas 1-3
        ...     modo="celdas"
        ... )
        
    Note:
        - Preserva las macros VBA del archivo (keep_vba=True)
        - Valida rangos contra contenido existente para evitar errores
        - El modo "todo" elimina todas las filas de la hoja
        - Los rangos usan indexación 1-based (fila 1 = primera fila)
        - Guarda automáticamente los cambios al finalizar
    """
    try:
        libro = openpyxl.load_workbook(ruta_archivo, keep_vba=True)

        if nombre_hoja not in libro.sheetnames:
            print(f"La hoja '{nombre_hoja}' no existe en el archivo.")
            return

        hoja = libro[nombre_hoja]

        # Verificar si la hoja está vacía
        hoja_vacia = (
                hoja.max_row == 1 and
                hoja.max_column == 1 and
                hoja.cell(row=1, column=1).value is None
        )

        if hoja_vacia and modo != "todo":
            print(f"La hoja '{nombre_hoja}' está vacía. No hay nada que borrar.")
            return

        if modo == "todo":
            hoja.delete_rows(1, hoja.max_row)
            print(f"Se eliminaron todas las filas de la hoja '{nombre_hoja}'.")

        elif modo == "filas" and rango_filas:
            fila_inicio, fila_fin = rango_filas
            if fila_inicio > hoja.max_row:
                print("El rango de filas está fuera del contenido actual. No se realizó ninguna acción.")
                return
            hoja.delete_rows(fila_inicio, fila_fin - fila_inicio + 1)
            print(f"Se eliminaron las filas {fila_inicio} a {fila_fin}.")

        elif modo == "columnas" and rango_columnas:
            col_inicio, col_fin = rango_columnas
            if col_inicio > hoja.max_column:
                print("El rango de columnas está fuera del contenido actual. No se realizó ninguna acción.")
                return
            hoja.delete_cols(col_inicio, col_fin - col_inicio + 1)
            print(f"Se eliminaron las columnas {col_inicio} a {col_fin}.")

        elif modo == "celdas" and rango_celdas:
            fila_ini, fila_fin, col_ini, col_fin = rango_celdas
            if fila_ini > hoja.max_row or col_ini > hoja.max_column:
                print("El rango de celdas está fuera del contenido actual. No se realizó ninguna acción.")
                return
            for fila in range(fila_ini, min(fila_fin + 1, hoja.max_row + 1)):
                for col in range(col_ini, min(col_fin + 1, hoja.max_column + 1)):
                    hoja.cell(row=fila, column=col).value = None
            print(f"Se eliminaron los valores de las celdas en el rango filas {fila_ini}-{fila_fin}, columnas {col_ini}-{col_fin}.")

        else:
            print("Parámetros insuficientes o modo inválido.")

        libro.save(ruta_archivo)
        print(f"Archivo guardado exitosamente: {ruta_archivo}")

    except FileNotFoundError:
        print(f"Error: El archivo '{ruta_archivo}' no fue encontrado.")
        raise
    except Exception as e:
        print(f"Error inesperado al limpiar la hoja: {e}")
        raise