import datetime
import holidays
from dateutil.relativedelta import relativedelta
from typing import Union


# ============================================================================
# FUNCIONES DE MANIPULACIÓN DE FECHAS
# ============================================================================

def ultimo_dia_laboral_del_mes(fecha: Union[datetime.date, datetime.datetime]
                               ) -> Union[datetime.date, datetime.datetime]:
    """
    Encuentra el último día laboral (hábil) de un mes dado.
    
    Calcula el último día del mes y luego retrocede hasta encontrar
    un día que no sea fin de semana ni feriado chileno.
    
    Args:
        fecha: Cualquier fecha dentro del mes del cual se quiere encontrar
               el último día laboral. Puede ser datetime.date o datetime.datetime.
        
    Returns:
        Último día laboral del mes. El tipo de retorno coincide con el tipo de entrada.
        
    Example:
        >>> from datetime import datetime, date
        >>> 
        >>> # Ejemplo con datetime
        >>> fecha = datetime(2023, 12, 15)  # Diciembre 2023
        >>> ultimo_laboral = ultimo_dia_laboral_del_mes(fecha)
        >>> print(f"Último día laboral de diciembre 2023: {ultimo_laboral}")
        >>> 
        >>> # Ejemplo con date
        >>> fecha = date(2023, 9, 10)  # Septiembre 2023
        >>> ultimo_laboral = ultimo_dia_laboral_del_mes(fecha)
        >>> print(f"Último día laboral: {ultimo_laboral}")
        >>> 
        >>> # Ejemplo especial: diciembre con 31 como feriado bancario
        >>> fecha = datetime(2023, 12, 1)  # Diciembre 2023
        >>> ultimo_laboral = ultimo_dia_laboral_del_mes(fecha)
        >>> print(f"Último día laboral de diciembre: {ultimo_laboral}")  # No será 31
        >>> 
        >>> # Para múltiples meses
        >>> meses = [datetime(2023, i, 1) for i in range(1, 13)]
        >>> for mes in meses:
        ...     ultimo = ultimo_dia_laboral_del_mes(mes)
        ...     print(f"{mes.strftime('%B')}: {ultimo.day}")
        
    Note:
        - Considera feriados oficiales de Chile (Región Metropolitana)
        - Incluye feriados bancarios con verificación explícita del 31 de diciembre
        - Retrocede desde el último día del mes hasta encontrar un día hábil
        - Fin de semana = sábado (5) y domingo (6)
        - Actualizado según calendario de feriados chilenos vigente
        - Usa la función es_dia_laboral() para consistencia en toda la biblioteca
    """
    ultimo_dia = ultimo_dia_del_mes(fecha)
    
    while not es_dia_laboral(ultimo_dia):
        ultimo_dia -= datetime.timedelta(days=1)
        
    return ultimo_dia

def ultimo_dia_del_mes(fecha: Union[datetime.date, datetime.datetime]
                       ) -> Union[datetime.date, datetime.datetime]:
    """
    Calcula el último día del mes para una fecha dada.
    
    Utiliza un algoritmo eficiente que funciona para cualquier mes,
    incluyendo años bisiestos.
    
    Args:
        fecha: Cualquier fecha dentro del mes. Puede ser datetime.date o datetime.datetime.
        
    Returns:
        Último día del mes. El tipo de retorno coincide con el tipo de entrada.
        
    Example:
        >>> from datetime import datetime, date
        >>> 
        >>> # Febrero en año bisiesto
        >>> fecha = datetime(2024, 2, 10)
        >>> ultimo = ultimo_dia_del_mes(fecha)
        >>> print(f"Último día de febrero 2024: {ultimo.day}")  # 29
        >>> 
        >>> # Febrero en año no bisiesto  
        >>> fecha = datetime(2023, 2, 10)
        >>> ultimo = ultimo_dia_del_mes(fecha)
        >>> print(f"Último día de febrero 2023: {ultimo.day}")  # 28
        >>> 
        >>> # Mes con 31 días
        >>> fecha = date(2023, 7, 15)
        >>> ultimo = ultimo_dia_del_mes(fecha)
        >>> print(f"Último día de julio: {ultimo.day}")  # 31
        >>> 
        >>> # Verificar para todos los meses
        >>> for mes in range(1, 13):
        ...     fecha_mes = datetime(2023, mes, 1)
        ...     ultimo_dia = ultimo_dia_del_mes(fecha_mes)
        ...     print(f"Mes {mes}: {ultimo_dia.day} días")
        
    Note:
        - Algoritmo: Ir al día 28 (existe en todos los meses) + 4 días (siguiente mes)
          luego restar los días del día actual para volver al mes anterior
        - Maneja automáticamente años bisiestos
        - Más eficiente que usar calendar.monthrange()
        - Conserva el tipo de la fecha de entrada (date vs datetime)
    """
    # El día 28 existe en todos los meses. 4 días después siempre es el siguiente mes
    next_month = fecha.replace(day=28) + datetime.timedelta(days=4)
    # Restar el número de días actuales nos devuelve al último día del mes anterior
    return next_month - datetime.timedelta(days=next_month.day)

def agrega_meses_a_fecha(fecha: Union[datetime.date, datetime.datetime],
                         meses: int
                         ) -> Union[datetime.date, datetime.datetime]:
    """
    Agrega una cantidad específica de meses a una fecha.
    
    Utiliza dateutil.relativedelta para manejar correctamente los casos
    especiales como fin de mes y años bisiestos.
    
    Args:
        fecha: Fecha base a la cual agregar meses. Puede ser date o datetime.
        meses: Número de meses a agregar. Puede ser positivo (futuro) 
               o negativo (pasado).
        
    Returns:
        Nueva fecha con los meses agregados. El tipo coincide con el de entrada.
        
    Example:
        >>> from datetime import datetime, date
        >>> 
        >>> # Agregar meses positivos
        >>> fecha = datetime(2023, 1, 31)
        >>> nueva_fecha = agrega_meses_a_fecha(fecha, 3)
        >>> print(f"31 enero + 3 meses: {nueva_fecha}")  # 30 abril (ajuste automático)
        >>> 
        >>> # Restar meses (valor negativo)
        >>> fecha = date(2023, 6, 15)
        >>> nueva_fecha = agrega_meses_a_fecha(fecha, -2)
        >>> print(f"15 junio - 2 meses: {nueva_fecha}")  # 15 abril
        >>> 
        >>> # Caso especial: fin de mes
        >>> fecha = datetime(2023, 1, 31)
        >>> nueva_fecha = agrega_meses_a_fecha(fecha, 1)
        >>> print(f"31 enero + 1 mes: {nueva_fecha}")  # 28 febrero (ajuste automático)
        >>> 
        >>> # Secuencia de fechas mensuales
        >>> fecha_base = datetime(2023, 1, 15)
        >>> fechas_mensuales = []
        >>> for i in range(12):
        ...     fecha_mes = agrega_meses_a_fecha(fecha_base, i)
        ...     fechas_mensuales.append(fecha_mes)
        ...     print(f"Mes {i+1}: {fecha_mes.strftime('%Y-%m-%d')}")
        
    Note:
        - Usa relativedelta en lugar de timedelta para precisión
        - Maneja automáticamente meses con diferente número de días
        - Si el día no existe en el mes destino, ajusta al último día válido
        - Ejemplo: 31 enero + 1 mes = 28 febrero (no 31 febrero)
        - Conserva el tipo de fecha de entrada (date vs datetime)
    """
    return fecha + relativedelta(months=meses)

def agregar_dias_laborales(fecha: datetime.datetime,
                           dias: int
                           ) -> list[datetime.datetime]:
    """
    Genera una lista de fechas laborales agregando días hábiles a una fecha base.
    
    Calcula una secuencia de días laborales (excluyendo fines de semana y feriados
    chilenos) a partir de una fecha inicial. Puede avanzar o retroceder en el tiempo.
    
    Args:
        fecha: Fecha inicial de referencia (debe ser datetime.datetime)
        dias: Número de días laborales a agregar. Positivo para avanzar,
              negativo para retroceder en el tiempo.
        
    Returns:
        Lista de fechas laborales que incluye la fecha inicial más los días
        hábiles solicitados. Total de elementos: abs(dias) + 1
        
    Example:
        >>> from datetime import datetime
        >>> 
        >>> # Agregar días laborales hacia adelante
        >>> fecha_inicial = datetime(2023, 11, 1)  # Miércoles
        >>> fechas = agregar_dias_laborales(fecha_inicial, 5)
        >>> for i, fecha in enumerate(fechas):
        ...     print(f"Día {i}: {fecha.strftime('%Y-%m-%d %A')}")
        >>> 
        >>> # Retroceder en días laborales
        >>> fecha_actual = datetime(2023, 11, 10)  # Viernes
        >>> fechas_pasadas = agregar_dias_laborales(fecha_actual, -3)
        >>> print(f"3 días laborales atrás: {fechas_pasadas[-1]}")
        >>> 
        >>> # Verificar que no hay fines de semana ni feriados
        >>> for fecha in fechas:
        ...     dia_semana = fecha.weekday()
        ...     es_laboral = dia_semana < 5  # Lunes=0 a Viernes=4
        ...     print(f"{fecha.strftime('%Y-%m-%d')}: Laboral={es_laboral}")
        
    Note:
        - La fecha inicial SIEMPRE se incluye en la lista (posición 0)
        - Solo cuenta días hábiles: Lunes a Viernes, excluyendo feriados
        - Usa calendario oficial de feriados de Chile (Región Metropolitana)
        - Para días negativos, retrocede en el tiempo
        - Desde holidays>=0.89, el 31 de diciembre está incluido como feriado bancario
        - Si solo necesitas la fecha final, usa agregar_x_dias_laborales()
    """
    fechas_habiles = [fecha]
    fecha_actual = fecha
    contador = 0
    incremento = 1 if dias > 0 else -1
    dias_absolutos = abs(dias)

    # Nota: La validación de días laborales se delega a es_dia_laboral()
    # que usa holidays>=0.89 donde el 31 de diciembre ya está incluido como feriado bancario

    while contador < dias_absolutos:
        fecha_actual += datetime.timedelta(days=incremento)
        
        if es_dia_laboral(fecha_actual):
            contador += 1
            
    return fechas_habiles

def es_dia_laboral(fecha: Union[datetime.date, datetime.datetime]) -> bool:
    """
    Verifica si una fecha dada es un día laboral (hábil) en Chile.
    
    Considera fines de semana, feriados oficiales chilenos (Región Metropolitana)
    y feriados bancarios incluyendo el 31 de diciembre.
    
    Args:
        fecha: Fecha a verificar. Puede ser datetime.date o datetime.datetime.
        
    Returns:
        True si la fecha es un día laboral, False si es fin de semana o feriado.
        
    Example:
        >>> from datetime import datetime, date
        >>> 
        >>> # Día laboral normal
        >>> fecha = datetime(2023, 11, 1)  # Miércoles
        >>> print(es_dia_laboral(fecha))  # True
        >>> 
        >>> # Fin de semana
        >>> fecha = date(2023, 11, 4)  # Sábado
        >>> print(es_dia_laboral(fecha))  # False
        >>> 
        >>> # Feriado oficial
        >>> fecha = datetime(2023, 9, 18)  # Fiestas Patrias
        >>> print(es_dia_laboral(fecha))  # False
        >>> 
        >>> # Feriado bancario: 31 de diciembre
        >>> fecha = datetime(2023, 12, 31)  # 31 de diciembre
        >>> print(es_dia_laboral(fecha))  # False
        >>> 
        >>> # Día laboral después de feriado
        >>> fecha = date(2024, 1, 2)  # 2 de enero (después del 31 dic)
        >>> print(es_dia_laboral(fecha))  # True
        >>> 
        >>> # Verificar múltiples fechas de fin de año
        >>> fechas_fin_año = [
        ...     datetime(2023, 12, 29),  # Viernes laboral
        ...     datetime(2023, 12, 30),  # Sábado (fin de semana)
        ...     datetime(2023, 12, 31),  # Domingo + feriado bancario
        ...     datetime(2024, 1, 1),    # Año nuevo (feriado)
        ...     datetime(2024, 1, 2),    # Martes laboral
        ... ]
        >>> for fecha in fechas_fin_año:
        ...     laboral = es_dia_laboral(fecha)
        ...     print(f"{fecha.strftime('%Y-%m-%d %A')}: {laboral}")
        
    Note:
        - Fin de semana: sábado (5) y domingo (6)
        - Considera feriados oficiales de Chile (Región Metropolitana)
        - Incluye feriados bancarios (categoría 'bank' de holidays)
        - Desde holidays>=0.89, el 31 de diciembre está incluido como feriado bancario,
          por lo que ya no requiere verificación manual
        - Útil para validaciones de días hábiles en operaciones bancarias y comerciales
    """
    # Convertir date a datetime si es necesario para consistencia interna
    if isinstance(fecha, datetime.date) and not isinstance(fecha, datetime.datetime):
        fecha = datetime.datetime.combine(fecha, datetime.time())
    
    chl_rm_feriados = holidays.country_holidays(country='CL', subdiv='RM')
    chl_rm_feriados_bancarios = holidays.country_holidays(country='CL', subdiv='RM', categories='bank')
    # Nota: Desde holidays>=0.89, el 31 de diciembre ya está incluido en feriados bancarios
    # por lo que no es necesario verificar es_31_diciembre manualmente

    es_laboral = ((fecha.weekday() < 5) 
                  and (fecha not in chl_rm_feriados) 
                  and (fecha not in chl_rm_feriados_bancarios))
    return es_laboral

def agregar_x_dias_laborales(fecha: Union[datetime.datetime, datetime.date],
                             dias: int) -> datetime.datetime:
    """
    Calcula la fecha resultante después de agregar días laborales a una fecha base.
    
    Función de conveniencia que retorna únicamente la fecha final después de
    agregar los días hábiles especificados, sin la lista intermedia.
    
    Args:
        fecha: Fecha base de inicio. Puede ser datetime.datetime o datetime.date
        dias: Número de días laborales a agregar. Positivo para avanzar,
              negativo para retroceder en el tiempo.
        
    Returns:
        datetime.datetime: Fecha final después de agregar los días laborales
        
    Example:
        >>> from datetime import datetime, date
        >>> 
        >>> # Agregar días laborales hacia adelante
        >>> fecha_inicial = datetime(2023, 11, 1)  # Miércoles
        >>> fecha_final = agregar_x_dias_laborales(fecha_inicial, 5)
        >>> print(f"5 días laborales después: {fecha_final.strftime('%Y-%m-%d %A')}")
        >>> 
        >>> # Retroceder días laborales
        >>> fecha_actual = datetime(2023, 11, 10)  # Viernes  
        >>> fecha_pasada = agregar_x_dias_laborales(fecha_actual, -3)
        >>> print(f"3 días laborales atrás: {fecha_pasada.strftime('%Y-%m-%d %A')}")
        >>> 
        >>> # Con date (se convierte automáticamente)
        >>> fecha_date = date(2023, 12, 1)
        >>> fecha_resultado = agregar_x_dias_laborales(fecha_date, 10)
        >>> print(f"10 días laborales después: {fecha_resultado}")
        >>> 
        >>> # Calcular fecha de vencimiento  
        >>> fecha_emision = datetime(2023, 11, 15)
        >>> dias_proceso = 7
        >>> fecha_vencimiento = agregar_x_dias_laborales(fecha_emision, dias_proceso)
        >>> print(f"Fecha de vencimiento: {fecha_vencimiento.strftime('%Y-%m-%d')}")
        
    Note:
        - Función de conveniencia equivalente a: agregar_dias_laborales(fecha, dias)[-1]
        - Siempre retorna datetime.datetime independiente del tipo de entrada
        - Más eficiente que generar toda la lista cuando solo se necesita el resultado final
        - Útil para cálculos de fechas de vencimiento y plazos de procesamiento
        - Considera feriados oficiales de Chile (Región Metropolitana)
    """
    # Convertir date a datetime si es necesario para consistencia interna
    if isinstance(fecha, datetime.date) and not isinstance(fecha, datetime.datetime):
        fecha = datetime.datetime.combine(fecha, datetime.time())
    
    return agregar_dias_laborales(fecha=fecha, dias=dias)[-1]