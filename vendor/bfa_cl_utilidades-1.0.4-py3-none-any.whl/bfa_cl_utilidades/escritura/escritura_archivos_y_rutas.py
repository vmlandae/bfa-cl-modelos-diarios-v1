import pandas as pd
import os
import glob
import openpyxl
import warnings
from typing import Literal, List, Optional
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
from google.cloud import bigquery, storage
from google.oauth2 import service_account
from openpyxl.utils.dataframe import dataframe_to_rows


# ============================================================================
# CLASE DE CARGA DE GCP: BIGQUERY Y STORAGE
# ============================================================================

warnings.filterwarnings('ignore', 
                        category=UserWarning, 
                        module='google.auth._default')
class CargaGCP:
    def __init__(self,
                 tipo_conexion: Literal['adc', 'cuenta_servicio'],
                 proyecto_id: str = None,
                 archivo_credenciales_json: str = None,
                 connection_string: str = None):
        """
        Inicializa la clase CargaGCP para conectarse a BigQuery y Google Cloud Storage.
        
        Args:
            tipo_conexion: Tipo de autenticación ('adc' para Application Default Credentials 
                         o 'cuenta_servicio' para archivo JSON)
            proyecto_id: ID del proyecto de Google Cloud Platform
            archivo_credenciales_json: Ruta al archivo JSON de credenciales de cuenta de servicio
            connection_string: String de conexión (actualmente no utilizado)
        """
        self.proyecto_id = proyecto_id
        self.tipo_conexion = tipo_conexion
        self.ruta_cuenta_servicio = archivo_credenciales_json
        self.connection_string = connection_string

    def _crear_cliente_bigquery(self) -> bigquery.Client:
        """
        Crea y retorna un cliente de BigQuery según el tipo de conexión configurado.
        Maneja todos los errores internamente e imprime mensajes informativos.
        
        Returns:
            bigquery.Client: Cliente autenticado de BigQuery, o None si hay error.
        """
        try:
            # Conexión usando Application Default Credentials (gcloud auth)
            if self.tipo_conexion == 'adc':
                return bigquery.Client(project=self.proyecto_id)
            
            # Conexión usando archivo JSON de cuenta de servicio
            if self.tipo_conexion == 'cuenta_servicio':
                if not self.ruta_cuenta_servicio:
                    print("ERROR: Falta ruta_cuenta_servicio para tipo_conexion 'cuenta_servicio'")
                    return None
                
                credenciales = service_account.Credentials.from_service_account_file(
                    self.ruta_cuenta_servicio
                )
                return bigquery.Client(credentials=credenciales, project=self.proyecto_id)
                
        except FileNotFoundError:
            print(f"ERROR: Archivo de credenciales no encontrado: '{self.ruta_cuenta_servicio}'")
            return None
        except Exception as e:
            print(f"ERROR: No se pudo inicializar el cliente BigQuery: {e}")
            return None

    def _crear_cliente_storage(self) -> storage.Client:
        """
        Crea y retorna un cliente de Google Cloud Storage usando las mismas credenciales que BigQuery.
        
        Returns:
            storage.Client: Cliente autenticado de Storage, o None si hay error.
        """
        try:
            # Conexión usando Application Default Credentials (gcloud auth)
            if self.tipo_conexion == 'adc':
                return storage.Client(project=self.proyecto_id)
            
            # Conexión usando archivo JSON de cuenta de servicio
            if self.tipo_conexion == 'cuenta_servicio':
                if not self.ruta_cuenta_servicio:
                    print("ERROR: Falta ruta_cuenta_servicio para tipo_conexion 'cuenta_servicio'")
                    return None
                    
                credenciales = service_account.Credentials.from_service_account_file(
                    self.ruta_cuenta_servicio
                )
                return storage.Client(credentials=credenciales, project=self.proyecto_id)
                
        except FileNotFoundError:
            print(f"ERROR: Archivo de credenciales no encontrado: '{self.ruta_cuenta_servicio}'")
            return None
        except Exception as e:
            print(f"ERROR: No se pudo inicializar el cliente Google Cloud Storage: {e}")
            return None
    
    def ejecutar_query_no_select(self, query: str, usar_legacy_sql: bool = False) -> None:
        """
        Ejecuta consultas DDL/DML en BigQuery que no retornan datos (CREATE, INSERT, UPDATE, DELETE).
        
        Args:
            query: Consulta SQL a ejecutar
            usar_legacy_sql: Si True, usa sintaxis SQL legacy. Por defecto False (SQL estándar)
            
        Returns:
            None: No retorna datos, solo imprime el resultado de la operación
        """

        # Validar parámetros requeridos
        if not self.proyecto_id:
            print("ERROR: proyecto_id no configurado en la clase. Configure al inicializar.")
            return
        
        # Crear cliente BigQuery usando el método de la clase
        client = self._crear_cliente_bigquery()
        if client is None:
            return

        # Configurar job de consulta
        job_config = bigquery.QueryJobConfig(
            use_legacy_sql=usar_legacy_sql
        )

        # Ejecutar consulta
        try:     
            job = client.query(query, job_config=job_config)
            job.result()  # Esperar a que termine
            
            print("\nConsulta ejecutada exitosamente")
            if hasattr(job, 'num_dml_affected_rows') and job.num_dml_affected_rows is not None:
                print(f"Filas afectadas: {job.num_dml_affected_rows}")
            
        except Exception as e:
            print(f"Error al ejecutar la consulta: {e}")
            print(f"Query ejecutada: {query[:200]}{'...' if len(query) > 200 else ''}")
        
    def cargar_dataframe_a_bigquery(self, 
                        data: pd.DataFrame,
                        dataset_id: str,
                        tabla_id: str,
                        tipo_escritura: Literal['TRUNCATE', 'APPEND', 'EMPTY'],
                        esquema_tabla: list = None) -> None:
        """
        Carga un DataFrame de pandas directamente a una tabla de BigQuery.
        
        Args:
            data: DataFrame de pandas con los datos a cargar
            dataset_id: ID del dataset en BigQuery
            tabla_id: ID de la tabla en BigQuery
            tipo_escritura: Modo de escritura ('TRUNCATE', 'APPEND', 'EMPTY')
            esquema_tabla: Lista de SchemaField de BigQuery. Si es None, se autodetecta
            
        Returns:
            None: Imprime el resultado de la operación
            
        Example:
            >>> df = pd.DataFrame({'id': [1, 2], 'nombre': ['A', 'B']})
            >>> carga.cargar_dataframe_a_bigquery(
            ...     data=df,
            ...     dataset_id="mi_dataset",
            ...     tabla_id="mi_tabla",
            ...     tipo_escritura="TRUNCATE"
            ... )
        """

        # Validar parámetros requeridos
        if not self.proyecto_id:
            print("ERROR: proyecto_id no configurado en la clase. Configure al inicializar.")
            return
        
        # Construir ruta completa de la tabla
        ruta_tabla_id = f"{self.proyecto_id}.{dataset_id}.{tabla_id}"

        # Crear cliente BigQuery usando el método de la clase
        client = self._crear_cliente_bigquery()
        if client is None:
            return

        # Mapeo de tipos de escritura a constantes de BigQuery
        tipo_escritura_mapping = {
            "TRUNCATE": bigquery.WriteDisposition.WRITE_TRUNCATE,
            "APPEND": bigquery.WriteDisposition.WRITE_APPEND,
            "EMPTY": bigquery.WriteDisposition.WRITE_EMPTY,
        }

        # Validar y obtener modo de escritura
        try:
            modo_escritura_actual = tipo_escritura_mapping[tipo_escritura.upper()]
        except KeyError:
            print(f"ERROR: Modo de escritura '{tipo_escritura}' no válido. "
                  f"Valores permitidos: {list(tipo_escritura_mapping.keys())}. ")


        # Configurar job de carga
        job_config = bigquery.LoadJobConfig(
            schema=esquema_tabla,
            write_disposition=modo_escritura_actual,
            autodetect=(esquema_tabla is None)
        )

        # Ejecutar carga de datos
        try:
            job = client.load_table_from_dataframe(data, ruta_tabla_id, job_config=job_config)
            job.result()  # Esperar a que termine
            
            print(f"Datos cargados exitosamente en '{ruta_tabla_id}'")
            print(f"Filas procesadas: {job.output_rows}")
            
        except Exception as e:
            print(f"Error al cargar los datos en BigQuery: {e}")

    def cargar_csv_a_bigquery(self, 
                              ruta_archivo_csv: str,
                              dataset_id: str,
                              tabla_id: str,
                              tipo_escritura: Literal['TRUNCATE', 'APPEND', 'EMPTY'],
                              esquema_tabla: list = None,
                              encoding: str = 'utf-8',
                              sep: str = ';',
                              decimal=',',
                              thousands='.',
                              **kwargs_pandas) -> None:
        """
        Carga un archivo CSV a BigQuery usando pandas para leer el archivo.
        Ideal para archivos con formatos no estándar (separadores, decimales, etc.).
        
        Args:
            ruta_archivo_csv: Ruta completa al archivo CSV local
            dataset_id: ID del dataset en BigQuery
            tabla_id: ID de la tabla en BigQuery
            tipo_escritura: Modo de escritura ('TRUNCATE', 'APPEND', 'EMPTY')
            esquema_tabla: Lista de SchemaField de BigQuery. Si es None, se autodetecta
            encoding: Codificación del archivo ('utf-8', 'latin-1', etc.)
            sep: Separador de campos (';', ',', '\t', etc.)
            decimal: Carácter para decimales (',', '.')
            thousands: Carácter para miles ('.', ',')
            **kwargs_pandas: Parámetros adicionales para pd.read_csv
            
        Returns:
            None: Imprime el resultado de la operación
            
        Example:
            >>> carga.cargar_csv_a_bigquery(
            ...     ruta_archivo_csv="/ruta/archivo.csv",
            ...     dataset_id="mi_dataset",
            ...     tabla_id="mi_tabla",
            ...     tipo_escritura="APPEND",
            ...     encoding="latin-1",
            ...     sep=";",
            ...     decimal=","
            ... )
        """
        # Validar parámetros requeridos
        if not self.proyecto_id:
            print("ERROR: proyecto_id no configurado en la clase. Configure al inicializar.")
            return
        
        # Validar existencia del archivo
        
        if not os.path.exists(ruta_archivo_csv):
            print(f"ERROR: El archivo CSV no existe: '{ruta_archivo_csv}'")
            return
        
        # Leer archivo CSV
        try:
            data = pd.read_csv(
                ruta_archivo_csv, 
                encoding=encoding, 
                sep=sep,
                decimal=decimal,
                thousands=thousands,
                **kwargs_pandas
            )
            
        except FileNotFoundError:
            print(f"ERROR: Archivo CSV no encontrado: '{ruta_archivo_csv}'")
            return
        except UnicodeDecodeError as e:
            print(f"ERROR: Error de codificación al leer el archivo. "
                  f"Intente cambiar el encoding (actual: {encoding}): {e}")
            return
        except pd.errors.EmptyDataError:
            print("ERROR: El archivo CSV está vacío o no contiene datos válidos.")
            return
        except Exception as e:
            print(f"ERROR: No se pudo leer el archivo CSV: {e}")
            return
        
        self.cargar_dataframe_a_bigquery(
            data=data,
            dataset_id=dataset_id,
            tabla_id=tabla_id,
            tipo_escritura=tipo_escritura,
            esquema_tabla=esquema_tabla
        )

    def cargar_csv_estandar_a_bigquery(self, 
                                       ruta_archivo_csv: str,
                                       dataset_id: str,
                                       tabla_id: str,
                                       tipo_escritura: Literal['TRUNCATE', 'APPEND', 'EMPTY'],
                                       esquema_tabla: list = None,
                                       saltar_lineas_encabezado: int = 1,
                                       encoding: str = 'UTF-8') -> None:
        """
        Carga un archivo CSV con formato estándar a BigQuery usando la API nativa.
        Más eficiente que cargar_csv_a_bigquery para archivos grandes con formato estándar
        (separador: coma, decimal: punto).
        
        Args:
            ruta_archivo_csv: Ruta completa al archivo CSV local
            dataset_id: ID del dataset en BigQuery
            tabla_id: ID de la tabla en BigQuery
            tipo_escritura: Modo de escritura ('TRUNCATE', 'APPEND', 'EMPTY')
            esquema_tabla: Lista de SchemaField de BigQuery. Si es None, se autodetecta
            saltar_lineas_encabezado: Número de líneas de encabezado a saltar
            encoding: Codificación del archivo ('UTF-8', 'ISO-8859-1', etc.)
            
        Returns:
            None: Imprime el resultado de la operación
            
        Example:
            >>> carga.cargar_csv_estandar_a_bigquery(
            ...     ruta_archivo_csv="/ruta/archivo_estandar.csv",
            ...     dataset_id="mi_dataset",
            ...     tabla_id="mi_tabla",
            ...     tipo_escritura="TRUNCATE",
            ...     saltar_lineas_encabezado=1,
            ...     encoding="UTF-8"
            ... )
        """
        # Validar parámetros requeridos
        if not self.proyecto_id:
            print("ERROR: proyecto_id no configurado en la clase. Configure al inicializar.")
            return
        
        # Validar existencia del archivo
        if not os.path.exists(ruta_archivo_csv):
            print(f"ERROR: El archivo CSV no existe: '{ruta_archivo_csv}'")
            return
        
        # Construir ruta completa de la tabla
        ruta_tabla_id = f"{self.proyecto_id}.{dataset_id}.{tabla_id}"

        # Crear cliente BigQuery usando el método de la clase
        client = self._crear_cliente_bigquery()
        if client is None:
            return

        # Mapeo de tipos de escritura a constantes de BigQuery
        tipo_escritura_mapping = {
            "TRUNCATE": bigquery.WriteDisposition.WRITE_TRUNCATE,
            "APPEND": bigquery.WriteDisposition.WRITE_APPEND,
            "EMPTY": bigquery.WriteDisposition.WRITE_EMPTY,
        }

        # Validar y obtener modo de escritura
        try:
            modo_escritura_actual = tipo_escritura_mapping[tipo_escritura.upper()]
        except KeyError:
            print(f"ERROR: Modo de escritura '{tipo_escritura}' no válido. "
                  f"Valores permitidos: {list(tipo_escritura_mapping.keys())}.")
            return

        # Configurar job de carga para CSV estándar
        job_config = bigquery.LoadJobConfig(
            source_format=bigquery.SourceFormat.CSV,
            schema=esquema_tabla,
            write_disposition=modo_escritura_actual,
            autodetect=(esquema_tabla is None),
            skip_leading_rows=saltar_lineas_encabezado,
            # Configuración estándar CSV
            field_delimiter=',',           # Separador: coma
            allow_quoted_newlines=True,    # Permitir saltos de línea en campos entrecomillados
            encoding=encoding
        )

        # Obtener información del archivo
        file_size = os.path.getsize(ruta_archivo_csv) / (1024 * 1024)  # MB
        
        # Ejecutar carga usando lectura binaria optimizada
        try:
            print(f"Archivo: {os.path.basename(ruta_archivo_csv)} ({file_size:.2f} MB)")
            print(f"Destino: '{ruta_tabla_id}'")
            print(f"Modo de escritura: {tipo_escritura.upper()}")
            print(f"Tipo de conexión: {self.tipo_conexion}")
            print(f"Configuración: separador=coma, decimal=punto, encoding={encoding}")
            
            # Lectura binaria optimizada
            with open(ruta_archivo_csv, "rb") as archivo_csv:
                job = client.load_table_from_file(
                    archivo_csv, 
                    ruta_tabla_id, 
                    job_config=job_config
                )
                job.result()  # Esperar a que termine
            
            print("\n CSV estándar cargado exitosamente")
            
        except FileNotFoundError:
            print(f"ERROR: Archivo CSV no encontrado: '{ruta_archivo_csv}'")
        except Exception as e:
            print(f"ERROR al cargar CSV estándar a BigQuery: {e}")

    def cargar_archivo_storage(self, 
                              ruta_archivo_local: str,
                              nombre_bucket: str,
                              directorio_destino_gcs: Optional[str] = None,
                              nombre_archivo_gcs: Optional[str] = None,
                              sobrescribir: bool = True) -> bool:
        """
        Sube un archivo local a Google Cloud Storage.
        
        Args:
            ruta_archivo_local: Ruta completa al archivo local
            nombre_bucket: Nombre del bucket de GCS
            directorio_destino_gcs: Directorio/carpeta destino en GCS (opcional, raíz si es None)
            nombre_archivo_gcs: Nombre del archivo en GCS (opcional, usa nombre original si es None)
            sobrescribir: Si True, sobrescribe el archivo si existe. Si False, falla si existe.
            
        Returns:
            bool: True si la carga fue exitosa, False en caso contrario
            
        Example:
            >>> # Guardar en la raíz del bucket con nombre original
            >>> carga.cargar_archivo_storage(
            ...     ruta_archivo_local="C:\\datos\\config.json",
            ...     nombre_bucket="mi-bucket"
            ... )
            >>> # Resultado: gs://mi-bucket/config.json
            >>>
            >>> # Guardar en directorio con nombre original
            >>> carga.cargar_archivo_storage(
            ...     ruta_archivo_local="C:\\datos\\mi_archivo.csv",
            ...     nombre_bucket="mi-bucket",
            ...     directorio_destino_gcs="modelos/2026/resultados"
            ... )
            >>> # Resultado: gs://mi-bucket/modelos/2026/resultados/mi_archivo.csv
            >>>
            >>> # Guardar en raíz con nombre personalizado
            >>> carga.cargar_archivo_storage(
            ...     ruta_archivo_local="C:\\datos\\mi_archivo.csv",
            ...     nombre_bucket="mi-bucket",
            ...     directorio_destino_gcs=None,
            ...     nombre_archivo_gcs="archivo_importante.csv"
            ... )
            >>> # Resultado: gs://mi-bucket/archivo_importante.csv
        """
        # Validar parámetros
        if not self.proyecto_id:
            print("ERROR: proyecto_id no configurado en la clase.")
            return False
            
        if not os.path.exists(ruta_archivo_local):
            print(f"ERROR: Archivo no encontrado: '{ruta_archivo_local}'")
            return False
            
        # Crear cliente Storage
        client = self._crear_cliente_storage()
        if client is None:
            return False
            
        try:
            # Obtener bucket
            bucket = client.bucket(nombre_bucket)
            
            # Definir nombre del archivo (usar original si no se especifica)
            if nombre_archivo_gcs is None:
                nombre_archivo_gcs = os.path.basename(ruta_archivo_local)
                
            # Construir ruta completa: directorio + nombre (o solo nombre si no hay directorio)
            if directorio_destino_gcs:
                # Asegurar que el directorio no termine con / para evitar //
                directorio_limpio = directorio_destino_gcs.rstrip('/')
                ruta_completa_gcs = f"{directorio_limpio}/{nombre_archivo_gcs}"
            else:
                # Sin directorio = archivo en la raíz del bucket
                ruta_completa_gcs = nombre_archivo_gcs
                
            # Verificar si el archivo ya existe
            blob = bucket.blob(ruta_completa_gcs)
            if blob.exists() and not sobrescribir:
                print(f"ERROR: El archivo '{ruta_completa_gcs}' ya existe en el bucket y sobrescribir=False")
                return False
                
            # Subir archivo
            file_size = os.path.getsize(ruta_archivo_local) / (1024 * 1024)  # MB
            print(f"Subiendo: {os.path.basename(ruta_archivo_local)} ({file_size:.2f} MB)")
            print(f"Destino: gs://{nombre_bucket}/{ruta_completa_gcs}")
            
            blob.upload_from_filename(ruta_archivo_local)
            
            print("Archivo subido exitosamente a GCS")
            return True
            
        except Exception as e:
            print(f"Error al subir archivo a GCS: {e}")
            return False

    def cargar_directorio_storage(self, 
                                 directorio_local: str,
                                 nombre_bucket: str,
                                 directorio_destino_gcs: str = "",
                                 extensiones_incluir: Optional[List[str]] = None,
                                 sobrescribir: bool = True,
                                 incluir_subdirectorios: bool = True) -> dict:
        """
        Sube múltiples archivos de un directorio a Google Cloud Storage.
        
        Args:
            directorio_local: Ruta al directorio local
            nombre_bucket: Nombre del bucket de GCS
            directorio_destino_gcs: Prefijo para las rutas en GCS (como carpeta)
            extensiones_incluir: Lista de extensiones a incluir (ej: ['.csv', '.txt']). None = todos
            sobrescribir: Si True, sobrescribe archivos existentes
            incluir_subdirectorios: Si True, incluye archivos de subdirectorios
            
        Returns:
            dict: Resumen con 'exitosos', 'fallidos', 'total', 'detalles'
        """
        # Validar parámetros
        if not self.proyecto_id:
            print("ERROR: proyecto_id no configurado en la clase.")
            return {'exitosos': 0, 'fallidos': 0, 'total': 0, 'detalles': []}
            
        if not os.path.exists(directorio_local):
            print(f"ERROR: Directorio no encontrado: '{directorio_local}'")
            return {'exitosos': 0, 'fallidos': 0, 'total': 0, 'detalles': []}
            
        if not os.path.isdir(directorio_local):
            print(f"ERROR: La ruta no es un directorio: '{directorio_local}'")
            return {'exitosos': 0, 'fallidos': 0, 'total': 0, 'detalles': []}
            
        # Crear cliente Storage
        client = self._crear_cliente_storage()
        if client is None:
            return {'exitosos': 0, 'fallidos': 0, 'total': 0, 'detalles': []}
            
        # Encontrar archivos
        patron_busqueda = "**/*" if incluir_subdirectorios else "*"
        archivos = glob.glob(os.path.join(directorio_local, patron_busqueda), recursive=incluir_subdirectorios)
        
        # Filtrar solo archivos (no directorios)
        archivos = [f for f in archivos if os.path.isfile(f)]
        
        # Filtrar por extensiones si se especifican
        if extensiones_incluir:
            extensiones_lower = [ext.lower() for ext in extensiones_incluir]
            archivos = [f for f in archivos if os.path.splitext(f)[1].lower() in extensiones_lower]
            
        if not archivos:
            print(f"WARNING: No se encontraron archivos en '{directorio_local}' con los criterios especificados")
            return {'exitosos': 0, 'fallidos': 0, 'total': 0, 'detalles': []}
            
        print(f"Iniciando carga de {len(archivos)} archivos desde '{directorio_local}'")
        print(f"Bucket destino: gs://{nombre_bucket}/{directorio_destino_gcs}")
        
        # Contadores
        exitosos = 0
        fallidos = 0
        detalles = []
        
        try:
            bucket = client.bucket(nombre_bucket)
            
            for archivo_local in archivos:
                try:
                    # Calcular ruta relativa desde el directorio base
                    ruta_relativa = os.path.relpath(archivo_local, directorio_local)
                    
                    # Normalizar separadores para GCS (usar /)
                    ruta_relativa_gcs = ruta_relativa.replace(os.sep, '/')
                    
                    # Construir ruta destino completa
                    if directorio_destino_gcs:
                        ruta_destino_gcs = f"{directorio_destino_gcs.rstrip('/')}/{ruta_relativa_gcs}"
                    else:
                        ruta_destino_gcs = ruta_relativa_gcs
                        
                    # Verificar si existe
                    blob = bucket.blob(ruta_destino_gcs)
                    if blob.exists() and not sobrescribir:
                        detalles.append({'archivo': ruta_relativa, 'estado': 'omitido', 'razon': 'ya_existe'})
                        continue
                        
                    # Subir archivo
                    file_size = os.path.getsize(archivo_local) / (1024 * 1024)  # MB
                    print(f"Subiendo: [{exitosos + 1}/{len(archivos)}] {ruta_relativa} ({file_size:.2f} MB)")
                    
                    blob.upload_from_filename(archivo_local)
                    
                    exitosos += 1
                    detalles.append({'archivo': ruta_relativa, 'estado': 'exitoso', 'destino_gcs': ruta_destino_gcs})
                    
                except Exception as e:
                    print(f"Error subiendo {ruta_relativa}: {e}")
                    fallidos += 1
                    detalles.append({'archivo': ruta_relativa, 'estado': 'fallido', 'error': str(e)})
                    
            # Resumen final
            print("\nResumen de carga:")
            print(f"Exitosos: {exitosos}")
            print(f"Fallidos: {fallidos}")
            print(f"Total procesados: {len(archivos)}")
            
            return {
                'exitosos': exitosos,
                'fallidos': fallidos, 
                'total': len(archivos),
                'detalles': detalles
            }
            
        except Exception as e:
            print(f"Error general al cargar directorio: {e}")
            return {'exitosos': exitosos, 'fallidos': fallidos, 'total': len(archivos), 'detalles': detalles}

  

# ============================================================================
# FUNCIONES DE RETROCOMPATIBILIDAD
# ============================================================================
def ejecutar_query_bigquery(ruta_cuenta_servicio: str, query: str) -> int:
    """
    Ejecuta una consulta DML (INSERT, UPDATE, DELETE) o DDL (CREATE, DROP) en BigQuery.

    Esta función está optimizada para operaciones que modifican datos o estructura,
    no para consultas SELECT que retornan datos.
    
    NOTA: Esta es una función legacy que internamente utiliza la clase CargaGCP.
    Para nuevos desarrollos, se recomienda usar directamente la clase CargaGCP.

    Args:
        ruta_cuenta_servicio (str): Ruta al archivo JSON de la cuenta de servicio
        query (str): Consulta SQL DML/DDL a ejecutar

    Returns:
        int: Número de filas afectadas por consultas DML (INSERT/UPDATE/DELETE).
             0 para consultas DDL (CREATE/DROP) o cuando no hay filas afectadas.
             -1 si ocurre una excepción durante la ejecución.

    Raises:
        No lanza excepciones directamente, pero las captura y retorna -1.

    Example:
        >>> # Insertar datos
        >>> filas_insertadas = ejecutar_query_bigquery(
        ...     "credenciales.json",
        ...     "INSERT INTO `proyecto.dataset.tabla` (col1) VALUES ('valor')"
        ... )
        >>> 
        >>> # Crear tabla
        >>> resultado = ejecutar_query_bigquery(
        ...     "credenciales.json", 
        ...     "CREATE TABLE `proyecto.dataset.nueva_tabla` (id INT64)"
        ... )
        
    Note:
        - Para consultas SELECT que retornan datos, use lectura_datos_bigquery()
        - La función espera a que la operación se complete antes de retornar
        - Los errores se imprimen en consola y retornan -1
        - Para nuevos desarrollos, use CargaGCP.ejecutar_query_no_select()
    """
    try:
        # Extraer proyecto_id del archivo de credenciales
        import json
        with open(ruta_cuenta_servicio, 'r') as f:
            credenciales_json = json.load(f)
            proyecto_id = credenciales_json.get('project_id')
        
        # Usar la clase CargaGCP internamente
        carga = CargaGCP(
            tipo_conexion='cuenta_servicio',
            proyecto_id=proyecto_id,
            archivo_credenciales_json=ruta_cuenta_servicio
        )
        
        # Crear cliente y ejecutar query
        client = carga._crear_cliente_bigquery()
        if client is None:
            return -1
            
        # Ejecutar consulta
        query_job = client.query(query)
        query_job.result()  # Esperar a que termine
        
        # Retornar filas afectadas para operaciones DML
        if query_job.num_dml_affected_rows is not None:
            return query_job.num_dml_affected_rows
            
        # Para DDL u otras operaciones sin filas afectadas
        return 0
        
    except FileNotFoundError:
        print(f"ERROR: Archivo de credenciales no encontrado: '{ruta_cuenta_servicio}'")
        return -1
    except Exception as e:
        print(f"Error inesperado: {e}")
        return -1

def cargar_dataframe_bigquery(data: pd.DataFrame,
                              ruta_cuenta_servicio: str,
                              proyecto_id: str,
                              dataset_id: str,
                              tabla_id: str,
                              tipo_escritura: str,
                              esquema_tabla: list = None) -> None:
    """
    Carga un DataFrame de pandas en una tabla de BigQuery.
    
    NOTA: Esta es una función legacy que internamente utiliza la clase CargaGCP.
    Para nuevos desarrollos, se recomienda usar directamente la clase CargaGCP.
    
    Args:
        data (pd.DataFrame): DataFrame con los datos a cargar
        ruta_cuenta_servicio (str): Ruta al archivo JSON de credenciales de servicio
        proyecto_id (str): ID del proyecto en Google Cloud
        dataset_id (str): ID del dataset dentro del proyecto
        tabla_id (str): ID de la tabla dentro del dataset
        tipo_escritura (str): Modo de escritura. Valores válidos:
                             - "TRUNCATE": Sobrescribe la tabla existente
                             - "APPEND": Añade datos a la tabla existente  
                             - "EMPTY": Falla si la tabla no está vacía
        esquema_tabla (list, optional): Schema de BigQuery para la tabla.
                                       Si es None, se usa detección automática.
    
    Returns:
        None: La función no retorna valores, imprime el resultado en consola
        
    Raises:
        No lanza excepciones directamente, las captura e imprime errores.
        
    Example:
        >>> import pandas as pd
        >>> df = pd.DataFrame({'col1': [1, 2], 'col2': ['a', 'b']})
        >>> cargar_dataframe_bigquery(
        ...     data=df,
        ...     ruta_cuenta_servicio="credenciales.json",
        ...     proyecto_id="mi-proyecto",
        ...     dataset_id="mi_dataset", 
        ...     tabla_id="mi_tabla",
        ...     tipo_escritura="APPEND"
        ... )
        
    Note:
        - Si tipo_escritura no es válido, usa "APPEND" por defecto
        - La función espera a que la carga se complete antes de continuar
        - Los errores se imprimen en consola para facilitar debugging
        - Para nuevos desarrollos, use CargaGCP.cargar_dataframe_a_bigquery()
    """
    # Validar tipo_escritura antes de pasar a la clase
    tipos_validos = ["TRUNCATE", "APPEND", "EMPTY"]
    if tipo_escritura.upper() not in tipos_validos:
        print(f"ERROR: Modo de escritura '{tipo_escritura}' no válido. "
              f"Valores permitidos: {tipos_validos}. "
              f"Usando 'APPEND' por defecto.")
        tipo_escritura = "APPEND"
    
    # Usar la clase CargaGCP internamente
    carga = CargaGCP(
        tipo_conexion='cuenta_servicio',
        proyecto_id=proyecto_id,
        archivo_credenciales_json=ruta_cuenta_servicio
    )
    
    # Delegar la carga al método de la clase
    carga.cargar_dataframe_a_bigquery(
        data=data,
        dataset_id=dataset_id,
        tabla_id=tabla_id,
        tipo_escritura=tipo_escritura,
        esquema_tabla=esquema_tabla
    )

# ============================================================================
# FUNCIONES DE ESCRITURA Y CARGA DE DATOS
# ============================================================================

def cargar_datos_ms_access(ruta: str,
                           nombre_tabla: str,
                           data: pd.DataFrame,
                           si_existe: Literal["fail", "replace", "append"]) -> None:
    """
    Carga un DataFrame de pandas en una tabla de Microsoft Access.
    
    Args:
        ruta (str): Ruta completa al archivo de base de datos Access (.mdb o .accdb)
        nombre_tabla (str): Nombre de la tabla donde cargar los datos
        data (pd.DataFrame): DataFrame con los datos a cargar
        si_existe (Literal["fail", "replace", "append"]): Comportamiento si la tabla existe:
                  - "fail": Falla si la tabla ya existe (por defecto en pandas)
                  - "replace": Reemplaza la tabla existente
                  - "append": Añade datos a la tabla existente
    
    Returns:
        None: La función no retorna valores
        
    Raises:
        Exception: Si hay errores de conexión, permisos o en la operación SQL
        
    Example:
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2], 'nombre': ['Juan', 'María']})
        >>> cargar_datos_ms_access(
        ...     ruta=r"C:\datos\mi_base.accdb",
        ...     nombre_tabla="usuarios",
        ...     data=df,
        ...     si_existe="append"
        ... )
        
    Note:
        - Requiere driver ODBC de Microsoft Access instalado
        - La función no crea el archivo .accdb si no existe
        - Los datos se cargan sin incluir el índice del DataFrame
        - La conexión se cierra automáticamente al finalizar
    """
    connection_str = r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};'
    connection_str += f'DBQ={ruta};'

    connection_url = URL.create("access+pyodbc", query={"odbc_connect": connection_str})
    engine = create_engine(connection_url)
    
    try:
        data.to_sql(nombre_tabla, engine, index=False, if_exists=si_existe, method=None)
        print(f"Datos cargados exitosamente en tabla '{nombre_tabla}' de Access")
        print(f"Filas cargadas: {len(data)}")
    except Exception as e:
        print(f"Error al cargar datos en Access: {e}")
        raise
    finally:
        engine.dispose()

def cargar_datos_xlsm(ruta_archivo: str,
                      nombre_hoja: str,
                      datos: pd.DataFrame,
                      formatos_columnas: dict = None) -> None:
    """
    Carga datos de un DataFrame en una hoja específica de un archivo Excel con macros (.xlsm).
    
    Preserva las macros VBA del archivo original y permite aplicar formatos personalizados
    a columnas específicas.
    
    Args:
        ruta_archivo (str): Ruta completa al archivo Excel (.xlsm)
        nombre_hoja (str): Nombre de la hoja donde cargar los datos.
                          Si no existe, se crea una nueva hoja.
        datos (pd.DataFrame): DataFrame con los datos a escribir
        formatos_columnas (dict, optional): Diccionario con formatos por columna.
                                          Clave: nombre de columna, Valor: formato Excel.
                                          Ejemplo: {"fecha": "dd/mm/yyyy", "monto": "#,##0.00"}
    
    Returns:
        None: La función no retorna valores, imprime el resultado en consola
        
    Raises:
        FileNotFoundError: Si el archivo Excel no existe
        Exception: Para otros errores durante la operación
        
    Example:
        >>> import pandas as pd
        >>> from datetime import datetime
        >>> 
        >>> df = pd.DataFrame({
        ...     'fecha': [datetime(2023, 1, 15)],
        ...     'monto': [1234.56],
        ...     'descripcion': ['Pago ejemplo']
        ... })
        >>> 
        >>> formatos = {
        ...     'fecha': 'dd/mm/yyyy',
        ...     'monto': '#,##0.00'
        ... }
        >>> 
        >>> cargar_datos_xlsm(
        ...     ruta_archivo=r"C:\reportes\archivo_con_macros.xlsm",
        ...     nombre_hoja="Datos",
        ...     datos=df,
        ...     formatos_columnas=formatos
        ... )
        
    Note:
        - Mantiene las macros VBA del archivo original (keep_vba=True)
        - Si la hoja existe, elimina todo su contenido antes de escribir
        - Si la hoja no existe, crea una nueva con el nombre especificado
        - Los formatos solo se aplican a las celdas de datos, no a headers
        - Usa formatos estándar de Excel (ej: "dd/mm/yyyy", "#,##0.00", "@" para texto)
    """
    try:
        # Cargar archivo preservando macros VBA
        libro = openpyxl.load_workbook(ruta_archivo, keep_vba=True)

        # Manejar hoja existente o crear nueva
        if nombre_hoja in libro.sheetnames:
            hoja = libro[nombre_hoja]
            # Limpiar contenido existente
            hoja.delete_rows(1, hoja.max_row + 1)
        else:
            # Crear nueva hoja si no existe
            hoja = libro.create_sheet(nombre_hoja)

        # Inicializar formatos si no se proporcionan
        if formatos_columnas is None:
            formatos_columnas = {}
            
        nombres_columnas = datos.columns.tolist()

        # Escribir datos con headers y aplicar formatos
        for fila_idx, fila_datos in enumerate(dataframe_to_rows(datos, index=False, header=True), start=1):
            for col_idx, valor in enumerate(fila_datos, start=1):
                celda = hoja.cell(row=fila_idx, column=col_idx, value=valor)

                # Aplicar formatos solo a celdas de datos (no headers)
                if fila_idx > 1 and col_idx <= len(nombres_columnas):
                    nombre_columna_actual = nombres_columnas[col_idx - 1]
                    if nombre_columna_actual in formatos_columnas:
                        formato_excel = formatos_columnas[nombre_columna_actual]
                        celda.number_format = formato_excel

        # Guardar cambios
        libro.save(ruta_archivo)
        print(f"Datos escritos exitosamente en hoja '{nombre_hoja}'")
        print(f"Filas escritas: {len(datos)} (+ 1 header)")
        if formatos_columnas:
            print(f"Formatos aplicados a {len(formatos_columnas)} columnas")

    except FileNotFoundError:
        print(f"Error: Archivo no encontrado '{ruta_archivo}'")
        raise
    except KeyError as e:
        print(f"Error: Problema con la hoja '{nombre_hoja}': {e}")
        raise
    except Exception as e:
        print(f"Error inesperado al escribir Excel: {e}")
        raise

