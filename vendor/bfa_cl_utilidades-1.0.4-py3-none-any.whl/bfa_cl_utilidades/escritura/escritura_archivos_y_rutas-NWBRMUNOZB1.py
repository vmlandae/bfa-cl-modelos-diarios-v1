import pandas as pd
from typing import Literal
from google.cloud import bigquery
from google.api_core import exceptions as gcp_exceptions
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows


# ============================================================================
# FUNCIONES DE ESCRITURA Y CARGA DE DATOS
# ============================================================================


def ejecutar_query_bigquery(ruta_cuenta_servicio: str, query: str) -> int:
    """
    Ejecuta una consulta DML (INSERT, UPDATE, DELETE) o DDL (CREATE, DROP) en BigQuery.

    Esta función está optimizada para operaciones que modifican datos o estructura,
    no para consultas SELECT que retornan datos.

    Args:
        ruta_cuenta_servicio (str): Ruta al archivo JSON de la cuenta de servicio
        query (str): Consulta SQL DML/DDL a ejecutar

    Returns:
        int: Número de filas afectadas por consultas DML (INSERT/UPDATE/DELETE).
             0 para consultas DDL (CREATE/DROP) o cuando no hay filas afectadas.
             -1 si ocurre una excepción durante la ejecución.

    Raises:
        No lanza excepciones directamente, pero las captura y retorna -1.

    Example:
        >>> # Insertar datos
        >>> filas_insertadas = ejecutar_query_bigquery(
        ...     "credenciales.json",
        ...     "INSERT INTO `proyecto.dataset.tabla` (col1) VALUES ('valor')"
        ... )
        >>> 
        >>> # Crear tabla
        >>> resultado = ejecutar_query_bigquery(
        ...     "credenciales.json", 
        ...     "CREATE TABLE `proyecto.dataset.nueva_tabla` (id INT64)"
        ... )
        
    Note:
        - Para consultas SELECT que retornan datos, use lectura_datos_bigquery()
        - La función espera a que la operación se complete antes de retornar
        - Los errores se imprimen en consola y retornan -1
    """
    try:
        # Inicializar cliente con credenciales de cuenta de servicio
        client = bigquery.Client.from_service_account_json(ruta_cuenta_servicio)

        # Ejecutar consulta de forma asíncrona
        query_job = client.query(query)

        # Esperar a que termine y validar que se completó exitosamente
        query_job.result()

        # Retornar filas afectadas para operaciones DML
        if query_job.num_dml_affected_rows is not None:
            return query_job.num_dml_affected_rows

        # Para DDL u otras operaciones sin filas afectadas
        return 0

    except gcp_exceptions.GoogleAPICallError as e:
        print(f"Error de API de Google Cloud durante la ejecución: {e}")
        return -1
    except Exception as e:
        print(f"Error inesperado: {e}")
        return -1

def cargar_dataframe_bigquery(data: pd.DataFrame,
                              ruta_cuenta_servicio: str,
                              proyecto_id: str,
                              dataset_id: str,
                              tabla_id: str,
                              tipo_escritura: str,
                              esquema_tabla: list = None) -> None:
    """
    Carga un DataFrame de pandas en una tabla de BigQuery.
    
    Args:
        data (pd.DataFrame): DataFrame con los datos a cargar
        ruta_cuenta_servicio (str): Ruta al archivo JSON de credenciales de servicio
        proyecto_id (str): ID del proyecto en Google Cloud
        dataset_id (str): ID del dataset dentro del proyecto
        tabla_id (str): ID de la tabla dentro del dataset
        tipo_escritura (str): Modo de escritura. Valores válidos:
                             - "TRUNCATE": Sobrescribe la tabla existente
                             - "APPEND": Añade datos a la tabla existente  
                             - "EMPTY": Falla si la tabla no está vacía
        esquema_tabla (list, optional): Schema de BigQuery para la tabla.
                                       Si es None, se usa detección automática.
    
    Returns:
        None: La función no retorna valores, imprime el resultado en consola
        
    Raises:
        No lanza excepciones directamente, las captura e imprime errores.
        
    Example:
        >>> import pandas as pd
        >>> df = pd.DataFrame({'col1': [1, 2], 'col2': ['a', 'b']})
        >>> cargar_dataframe_bigquery(
        ...     data=df,
        ...     ruta_cuenta_servicio="credenciales.json",
        ...     proyecto_id="mi-proyecto",
        ...     dataset_id="mi_dataset", 
        ...     tabla_id="mi_tabla",
        ...     tipo_escritura="APPEND"
        ... )
        
    Note:
        - Si tipo_escritura no es válido, usa "APPEND" por defecto
        - La función espera a que la carga se complete antes de continuar
        - Los errores se imprimen en consola para facilitar debugging
    """
    ruta_tabla_id = f"{proyecto_id}.{dataset_id}.{tabla_id}"

    # Inicializar cliente BigQuery con manejo de errores
    try:
        client = bigquery.Client.from_service_account_json(ruta_cuenta_servicio)
    except FileNotFoundError:
        print(f"ERROR: Archivo de credenciales no encontrado: '{ruta_cuenta_servicio}'")
        return
    except Exception as e:
        print(f"ERROR: No se pudo inicializar el cliente BigQuery: {e}")
        return

    # Mapeo de tipos de escritura a constantes de BigQuery
    tipo_escritura_mapping = {
        "TRUNCATE": bigquery.WriteDisposition.WRITE_TRUNCATE,
        "APPEND": bigquery.WriteDisposition.WRITE_APPEND,
        "EMPTY": bigquery.WriteDisposition.WRITE_EMPTY,
    }

    # Validar y obtener modo de escritura
    try:
        modo_escritura_actual = tipo_escritura_mapping[tipo_escritura.upper()]
    except KeyError:
        print(f"ERROR: Modo de escritura '{tipo_escritura}' no válido. "
              f"Valores permitidos: {list(tipo_escritura_mapping.keys())}. "
              f"Usando 'APPEND' por defecto.")
        modo_escritura_actual = bigquery.WriteDisposition.WRITE_APPEND

    # Configurar job de carga
    job_config = bigquery.LoadJobConfig(
        schema=esquema_tabla,
        write_disposition=modo_escritura_actual,
        autodetect=(esquema_tabla is None)
    )

    # Ejecutar carga de datos
    try:
        job = client.load_table_from_dataframe(data, ruta_tabla_id, job_config=job_config)
        job.result()  # Esperar a que termine
        
        print(f"\nDatos cargados exitosamente en '{ruta_tabla_id}'")
        print(f"Filas procesadas: {job.output_rows}")
        print(f"Modo de escritura: {tipo_escritura.upper()}")
        
    except Exception as e:
        print(f"Error al cargar los datos en BigQuery: {e}")

def cargar_datos_ms_access(ruta: str,
                           nombre_tabla: str,
                           data: pd.DataFrame,
                           si_existe: Literal["fail", "replace", "append"]) -> None:
    """
    Carga un DataFrame de pandas en una tabla de Microsoft Access.
    
    Args:
        ruta (str): Ruta completa al archivo de base de datos Access (.mdb o .accdb)
        nombre_tabla (str): Nombre de la tabla donde cargar los datos
        data (pd.DataFrame): DataFrame con los datos a cargar
        si_existe (Literal["fail", "replace", "append"]): Comportamiento si la tabla existe:
                  - "fail": Falla si la tabla ya existe (por defecto en pandas)
                  - "replace": Reemplaza la tabla existente
                  - "append": Añade datos a la tabla existente
    
    Returns:
        None: La función no retorna valores
        
    Raises:
        Exception: Si hay errores de conexión, permisos o en la operación SQL
        
    Example:
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2], 'nombre': ['Juan', 'María']})
        >>> cargar_datos_ms_access(
        ...     ruta=r"C:\datos\mi_base.accdb",
        ...     nombre_tabla="usuarios",
        ...     data=df,
        ...     si_existe="append"
        ... )
        
    Note:
        - Requiere driver ODBC de Microsoft Access instalado
        - La función no crea el archivo .accdb si no existe
        - Los datos se cargan sin incluir el índice del DataFrame
        - La conexión se cierra automáticamente al finalizar
    """
    connection_str = r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};'
    connection_str += f'DBQ={ruta};'

    connection_url = URL.create("access+pyodbc", query={"odbc_connect": connection_str})
    engine = create_engine(connection_url)
    
    try:
        data.to_sql(nombre_tabla, engine, index=False, if_exists=si_existe, method=None)
        print(f"Datos cargados exitosamente en tabla '{nombre_tabla}' de Access")
        print(f"Filas cargadas: {len(data)}")
    except Exception as e:
        print(f"Error al cargar datos en Access: {e}")
        raise
    finally:
        engine.dispose()

def cargar_datos_xlsm(ruta_archivo: str,
                      nombre_hoja: str,
                      datos: pd.DataFrame,
                      formatos_columnas: dict = None) -> None:
    """
    Carga datos de un DataFrame en una hoja específica de un archivo Excel con macros (.xlsm).
    
    Preserva las macros VBA del archivo original y permite aplicar formatos personalizados
    a columnas específicas.
    
    Args:
        ruta_archivo (str): Ruta completa al archivo Excel (.xlsm)
        nombre_hoja (str): Nombre de la hoja donde cargar los datos.
                          Si no existe, se crea una nueva hoja.
        datos (pd.DataFrame): DataFrame con los datos a escribir
        formatos_columnas (dict, optional): Diccionario con formatos por columna.
                                          Clave: nombre de columna, Valor: formato Excel.
                                          Ejemplo: {"fecha": "dd/mm/yyyy", "monto": "#,##0.00"}
    
    Returns:
        None: La función no retorna valores, imprime el resultado en consola
        
    Raises:
        FileNotFoundError: Si el archivo Excel no existe
        Exception: Para otros errores durante la operación
        
    Example:
        >>> import pandas as pd
        >>> from datetime import datetime
        >>> 
        >>> df = pd.DataFrame({
        ...     'fecha': [datetime(2023, 1, 15)],
        ...     'monto': [1234.56],
        ...     'descripcion': ['Pago ejemplo']
        ... })
        >>> 
        >>> formatos = {
        ...     'fecha': 'dd/mm/yyyy',
        ...     'monto': '#,##0.00'
        ... }
        >>> 
        >>> cargar_datos_xlsm(
        ...     ruta_archivo=r"C:\reportes\archivo_con_macros.xlsm",
        ...     nombre_hoja="Datos",
        ...     datos=df,
        ...     formatos_columnas=formatos
        ... )
        
    Note:
        - Mantiene las macros VBA del archivo original (keep_vba=True)
        - Si la hoja existe, elimina todo su contenido antes de escribir
        - Si la hoja no existe, crea una nueva con el nombre especificado
        - Los formatos solo se aplican a las celdas de datos, no a headers
        - Usa formatos estándar de Excel (ej: "dd/mm/yyyy", "#,##0.00", "@" para texto)
    """
    try:
        # Cargar archivo preservando macros VBA
        libro = openpyxl.load_workbook(ruta_archivo, keep_vba=True)

        # Manejar hoja existente o crear nueva
        if nombre_hoja in libro.sheetnames:
            hoja = libro[nombre_hoja]
            # Limpiar contenido existente
            hoja.delete_rows(1, hoja.max_row + 1)
        else:
            # Crear nueva hoja si no existe
            hoja = libro.create_sheet(nombre_hoja)

        # Inicializar formatos si no se proporcionan
        if formatos_columnas is None:
            formatos_columnas = {}
            
        nombres_columnas = datos.columns.tolist()

        # Escribir datos con headers y aplicar formatos
        for fila_idx, fila_datos in enumerate(dataframe_to_rows(datos, index=False, header=True), start=1):
            for col_idx, valor in enumerate(fila_datos, start=1):
                celda = hoja.cell(row=fila_idx, column=col_idx, value=valor)

                # Aplicar formatos solo a celdas de datos (no headers)
                if fila_idx > 1 and col_idx <= len(nombres_columnas):
                    nombre_columna_actual = nombres_columnas[col_idx - 1]
                    if nombre_columna_actual in formatos_columnas:
                        formato_excel = formatos_columnas[nombre_columna_actual]
                        celda.number_format = formato_excel

        # Guardar cambios
        libro.save(ruta_archivo)
        print(f"Datos escritos exitosamente en hoja '{nombre_hoja}'")
        print(f"Filas escritas: {len(datos)} (+ 1 header)")
        if formatos_columnas:
            print(f"Formatos aplicados a {len(formatos_columnas)} columnas")

    except FileNotFoundError:
        print(f"Error: Archivo no encontrado '{ruta_archivo}'")
        raise
    except KeyError as e:
        print(f"Error: Problema con la hoja '{nombre_hoja}': {e}")
        raise
    except Exception as e:
        print(f"Error inesperado al escribir Excel: {e}")
        raise