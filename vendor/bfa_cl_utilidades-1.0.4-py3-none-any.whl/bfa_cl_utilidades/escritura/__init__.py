"""
Módulo de escritura y carga de datos.

Contiene funciones para escribir y cargar datos hacia diversas
destinaciones como Google BigQuery, Microsoft Access y archivos Excel.

Clases disponibles:
    - CargaGCP: Clase principal para cargar datos a BigQuery y Google Cloud Storage

Funciones legacy (retrocompatibilidad):
    - ejecutar_query_bigquery: Ejecuta queries DDL/DML en BigQuery
    - cargar_dataframe_bigquery: Carga DataFrames a BigQuery
"""

from .escritura_archivos_y_rutas import (
    # Clase principal (recomendada para nuevos desarrollos)
    CargaGCP,
    cargar_datos_ms_access,
    cargar_datos_xlsm,
    # Funciones legacy (retrocompatibilidad)
    ejecutar_query_bigquery,
    cargar_dataframe_bigquery,
)

__all__ = [
    # Clase principal
    "CargaGCP",
    "cargar_datos_ms_access",
    "cargar_datos_xlsm",
    # Funciones legacy
    "ejecutar_query_bigquery",
    "cargar_dataframe_bigquery",
]