import pandas as pd
import numpy as np
import datetime
from typing import Union


# ============================================================================
# FUNCIONES FINANCIERAS Y MATEMÁTICAS
# ============================================================================

# ============================================================================
# FUNCIONES DE INTERPOLACIÓN
# ============================================================================

def lin_interpol(valores: Union[int, float, list, pd.Series, np.ndarray],
                 x: Union[list, pd.Series, np.ndarray],
                 y: Union[list, pd.Series, np.ndarray]
                 ) -> Union[float, list, pd.Series, np.ndarray]:
    """
    Realiza interpolación lineal de datos basada en puntos de referencia X e Y.
    
    Utiliza la función np.interp para calcular valores interpolados linealmente
    entre los puntos dados.
    
    Args:
        valores: Valores en los que se desea interpolar. Puede ser escalar o array.
        x: Variable independiente (puntos de referencia en X). Debe estar ordenada.
        y: Variable dependiente (valores correspondientes en Y).
        
    Returns:
        Valores interpolados. El tipo de retorno depende del tipo de entrada.
        
    Raises:
        ValueError: Si x no está ordenado o si x e y tienen diferentes longitudes.
        
    Example:
        >>> # Interpolación simple
        >>> x_ref = [1, 2, 4]
        >>> y_ref = [10, 20, 40]
        >>> resultado = lin_interpol(3, x_ref, y_ref)
        >>> print(resultado)  # 30.0
        >>> 
        >>> # Con arrays
        >>> import numpy as np
        >>> valores = np.array([1.5, 2.5, 3.5])
        >>> result = lin_interpol(valores, x_ref, y_ref)
        
    Note:
        - Los valores de x deben estar en orden ascendente
        - Para valores fuera del rango de x, se usa extrapolación lineal
        - La función maneja automáticamente diferentes tipos de datos de entrada
    """
    return np.interp(valores, x, y)


def loglin_interpol(valores: Union[int, float, list, pd.Series, np.ndarray],
                    x: Union[list, pd.Series, np.ndarray],
                    y: Union[list, pd.Series, np.ndarray]
                    ) -> Union[float, list, pd.Series, np.ndarray]:
    """
    Realiza interpolación logarítmica-lineal de datos.
    
    Esta función transforma los valores Y al espacio logarítmico, realiza
    interpolación lineal, y luego convierte de vuelta al espacio original.
    Es útil para datos que siguen un crecimiento exponencial.
    
    Args:
        valores: Valores en los que se desea interpolar. Puede ser escalar o array.
        x: Variable independiente (puntos de referencia en X). Debe estar ordenada.
        y: Variable dependiente (valores correspondientes en Y). Debe ser > 0.
        
    Returns:
        Valores interpolados en escala original. El tipo de retorno depende del tipo de entrada.
        
    Raises:
        ValueError: Si algún valor en y es <= 0 (no se puede calcular logaritmo).
        
    Example:
        >>> # Para datos con crecimiento exponencial
        >>> x_ref = [1, 2, 3, 4]
        >>> y_ref = [2, 4, 8, 16]  # Crecimiento exponencial
        >>> resultado = loglin_interpol(2.5, x_ref, y_ref)
        >>> print(f"Interpolación log-lineal: {resultado:.2f}")  # ~5.66
        >>> 
        >>> # Comparar con interpolación lineal normal
        >>> resultado_lineal = lin_interpol(2.5, x_ref, y_ref)
        >>> print(f"Interpolación lineal: {resultado_lineal}")  # 6.0
        
    Note:
        - Todos los valores en y deben ser estrictamente positivos
        - Más apropiada que interpolación lineal para datos exponenciales
        - La transformación logarítmica preserva las proporciones relativas
    """
    return np.exp(np.interp(valores, x, np.log(y)))


# ============================================================================
# FUNCIONES FINANCIERAS GENERALES
# ============================================================================

def calculo_plazo_medio_permanencia(plazo: Union[list, pd.Series, np.ndarray],
                                    montos: Union[list, pd.Series, np.ndarray],
                                    divisor: Union[int, float] = 365
                                    ) -> float:
    """
    Calcula el plazo medio de permanencia ponderado por montos.
    
    Esta función calcula un promedio ponderado donde los plazos se pesan
    por los montos correspondientes, útil para análisis de portafolios
    y duración de inversiones.
    
    Args:
        plazo: Secuencia de plazos en días
        montos: Secuencia de montos correspondientes a cada plazo
        divisor: Divisor para convertir días a fracción de año (default: 365)
        
    Returns:
        float: Plazo medio de permanencia en años (dividido por divisor)
        
    Raises:
        ValueError: Si las secuencias tienen diferentes longitudes o divisor es 0
        TypeError: Si los tipos de entrada no son soportados
        
    Example:
        >>> # Ejemplo con listas
        >>> plazos = [30, 60, 90]
        >>> montos = [1000, 2000, 1500]
        >>> pmp = calculo_plazo_medio_permanencia(plazos, montos)
        >>> print(f"Plazo medio: {pmp:.3f} años")
        >>> 
        >>> # Ejemplo con pandas Series
        >>> import pandas as pd
        >>> df = pd.DataFrame({
        ...     'plazo': [30, 60, 90, 120],
        ...     'monto': [1000, 2000, 1500, 500]
        ... })
        >>> pmp = calculo_plazo_medio_permanencia(df['plazo'], df['monto'])
        
    Note:
        - El cálculo es: sum(plazo_i * monto_i) / sum(monto_i) / divisor
        - Soporta listas, pandas Series y numpy arrays
        - Maneja automáticamente tipos mixtos convirtiéndolos a numpy arrays
        - Un divisor de 365 convierte días a años, 30 convierte días a meses
    """
    # Validaciones de entrada
    if len(plazo) != len(montos):
        raise ValueError("Las secuencias 'plazo' y 'montos' deben tener la misma longitud.")

    if divisor == 0:
        raise ValueError("El divisor no puede ser cero.")
        
    if len(plazo) == 0:
        return 0.0

    # Cálculo optimizado por tipo de datos
    if isinstance(plazo, pd.Series) and isinstance(montos, pd.Series):
        total_producto = (plazo * montos).sum() / montos.sum()
    elif isinstance(plazo, list) and isinstance(montos, list):
        total_producto = sum(p * m for p, m in zip(plazo, montos))
        total_producto = total_producto / sum(montos)
    elif isinstance(plazo, np.ndarray) and isinstance(montos, np.ndarray):
        total_producto = (plazo * montos).sum() / montos.sum()
    else:
        # Manejo de tipos mixtos con conversión a NumPy
        try:
            plazo_np = np.array(plazo)
            montos_np = np.array(montos)
            total_producto = (plazo_np * montos_np).sum() / montos_np.sum()
        except Exception as e:
            raise TypeError(f"Tipos de entrada no soportados: "
                            f"{type(plazo).__name__}, {type(montos).__name__}. Error: {e}")
                            
    return total_producto / divisor

def calculo_tasa_forward(tasa_corta: Union[int, float, list, pd.Series, np.ndarray],
                         tasa_larga: Union[int, float, list, pd.Series, np.ndarray],
                         plazo_corto: Union[int, float, list, pd.Series, np.ndarray],
                         plazo_largo: Union[int, float, list, pd.Series, np.ndarray]
                         ) -> Union[float, list, pd.Series, np.ndarray]:
    """
    Calcula la tasa forward implícita entre dos plazos.
    
    La tasa forward representa la tasa de interés esperada para un período
    futuro, derivada de las tasas spot actuales. Es fundamental para
    valoración de instrumentos financieros y gestión de riesgo.
    
    Args:
        tasa_corta: Tasa de interés para el plazo más corto (decimal, ej: 0.05 para 5%)
        tasa_larga: Tasa de interés para el plazo más largo (decimal)
        plazo_corto: Plazo más corto en años o fracciones de año
        plazo_largo: Plazo más largo en años o fracciones de año
        
    Returns:
        Tasa forward implícita (en decimal). El tipo de retorno coincide con el de entrada.
        
    Raises:
        ValueError: Si plazo_largo <= plazo_corto
        
    Example:
        >>> # Ejemplo básico
        >>> tasa_6m = 0.03  # 3% semestral
        >>> tasa_1y = 0.04  # 4% anual  
        >>> plazo_6m = 0.5  # 6 meses
        >>> plazo_1y = 1.0  # 1 año
        >>> 
        >>> tasa_fwd = calculo_tasa_forward(tasa_6m, tasa_1y, plazo_6m, plazo_1y)
        >>> print(f"Tasa forward 6M-1Y: {tasa_fwd:.4f} ({tasa_fwd*100:.2f}%)")
        >>> 
        >>> # Con arrays para múltiples cálculos
        >>> import numpy as np
        >>> tasas_cortas = np.array([0.02, 0.025, 0.03])
        >>> tasas_largas = np.array([0.035, 0.04, 0.045])
        >>> forwards = calculo_tasa_forward(tasas_cortas, tasas_largas, 0.5, 1.0)
        
    Note:
        - Fórmula: [(1 + r_long)^(T_long/ΔT) / (1 + r_short)^(T_short/ΔT)] - 1
        - donde ΔT = T_long - T_short
        - Las tasas deben estar en formato decimal (no porcentual)
        - Soporta cálculos vectorizados con arrays de NumPy o pandas Series
    """
    dif_plazos = plazo_largo - plazo_corto
    
    if isinstance(dif_plazos, (int, float)) and dif_plazos <= 0:
        raise ValueError("El plazo largo debe ser mayor que el plazo corto")
    elif hasattr(dif_plazos, '__iter__') and np.any(dif_plazos <= 0):
        raise ValueError("Todos los plazos largos deben ser mayores que los plazos cortos")
    
    return (np.power((1 + tasa_larga), plazo_largo / dif_plazos) / 
            np.power((1 + tasa_corta), plazo_corto / dif_plazos)) - 1

def calculo_curva_forward(
    df_base: pd.DataFrame,
    plazo_fwd_ini: Union[int, float, list, pd.Series, np.ndarray],
    plazo_fwd_fin: Union[int, float, list, pd.Series, np.ndarray]
) -> Union[float, np.ndarray]:
    """
    Calcula el valor de la curva forward usando interpolación log-lineal.
    
    Esta función interpola factores de descuento para calcular el valor
    de la curva forward entre dos plazos.
    
    Args:
        df_base: DataFrame con al menos dos columnas numéricas:
                 - Primera columna: plazos (variable independiente)
                 - Segunda columna: factores de descuento (DF)
        plazo_fwd_ini: Plazo inicial forward. Acepta int, float, list, pd.Series o np.ndarray
        plazo_fwd_fin: Plazo final forward. Acepta int, float, list, pd.Series o np.ndarray
        
    Returns:
        Valor interpolado de la curva forward. Tipo de retorno depende del input:
        - Si plazo_fwd_ini/fin son escalares (int/float): retorna float
        - Si son arrays (list/Series/ndarray): retorna np.ndarray
        
    Raises:
        TypeError: Si df_base no es DataFrame o columnas no son numéricas
        ValueError: Si df_base no tiene al menos dos columnas o dos filas
        
    Example:
        >>> import pandas as pd
        >>> import numpy as np
        >>> 
        >>> # Crear curva base de factores de descuento
        >>> df_curva = pd.DataFrame({
        ...     'Plazo': [0.25, 0.5, 1.0, 2.0, 5.0],
        ...     'FD': [0.990, 0.980, 0.960, 0.920, 0.820]
        ... })
        >>> 
        >>> # Calcular forward entre 1 y 2 años
        >>> fwd_value = calculo_curva_forward(df_curva, 1.0, 2.0)
        >>> print(f"Valor forward 1Y-2Y: {fwd_value:.6f}")
        >>> 
        >>> # Con múltiples plazos
        >>> plazos_ini = np.array([0.5, 1.0, 2.0])
        >>> plazos_fin = np.array([1.0, 2.0, 5.0])
        >>> fwd_values = calculo_curva_forward(df_curva, plazos_ini, plazos_fin)
        >>> print("Valores forward:", fwd_values)
        
    Note:
        - Utiliza interpolación log-lineal para factores de descuento
        - Fórmula: FD(T_ini) / FD(T_fin) donde FD son interpolados
        - Los plazos deben estar en las mismas unidades que df_base (días)
    """
    if not isinstance(df_base, pd.DataFrame):
        raise TypeError("df_base debe ser un DataFrame de pandas.")
    if df_base.shape[1] < 2:
        raise ValueError("df_base debe tener al menos dos columnas: plazos y DF.")
    if df_base.shape[0] < 2:
        raise ValueError("df_base debe tener al menos dos filas para interpolar.")
    
    plazo_base = df_base.iloc[:, 0]
    df_col = df_base.iloc[:, 1]
    
    if not (np.issubdtype(plazo_base.dtype, np.number) and np.issubdtype(df_col.dtype, np.number)):
        raise TypeError("Las dos primeras columnas de df_base deben ser numéricas (plazos y DF).")
    
    return loglin_interpol(plazo_fwd_fin, plazo_base, df_col) / loglin_interpol(plazo_fwd_ini, plazo_base, df_col)
# ============================================================================
# FUNCIONES DE CÁLCULO DE YEAR FRACTION (FRACCIÓN DE AÑO)
# ============================================================================

def calculo_yf_actual_360(plazo: Union[int, float, pd.Series, np.ndarray]
                          ) -> Union[float, pd.Series, np.ndarray]:
    """
    Calcula la fracción de año usando la convención Actual/360.
    
    Esta convención divide los días reales por 360, comúnmente usada
    en mercados monetarios y algunos bonos corporativos.
    
    Args:
        plazo: Número de días (puede ser escalar, Series o array)
        
    Returns:
        Fracción de año equivalente. El tipo de retorno coincide con el de entrada.
        
    Example:
        >>> # 30 días bajo convención Actual/360
        >>> yf = calculo_yf_actual_360(30)
        >>> print(f"30 días = {yf:.6f} años")  # 0.083333
        >>> 
        >>> # Con múltiples plazos
        >>> import pandas as pd
        >>> plazos = pd.Series([30, 60, 90, 180])
        >>> yf_series = calculo_yf_actual_360(plazos)
        >>> print(yf_series)
        
    Note:
        - Fórmula: días / 360
        - Común en USD y mercados monetarios
        - Resulta en fracciones ligeramente mayores que Actual/365
    """
    return plazo / 360


def calculo_yf_actual_365(plazo: Union[int, float, pd.Series, np.ndarray]
                          ) -> Union[float, pd.Series, np.ndarray]:
    """
    Calcula la fracción de año usando la convención Actual/365.
    
    Esta convención divide los días reales por 365, usada comúnmente
    en bonos del tesoro y muchos mercados internacionales.
    
    Args:
        plazo: Número de días (puede ser escalar, Series o array)
        
    Returns:
        Fracción de año equivalente. El tipo de retorno coincide con el de entrada.
        
    Example:
        >>> # 30 días bajo convención Actual/365
        >>> yf = calculo_yf_actual_365(30)
        >>> print(f"30 días = {yf:.6f} años")  # 0.082192
        >>> 
        >>> # Comparación con Actual/360
        >>> yf_360 = calculo_yf_actual_360(30)
        >>> yf_365 = calculo_yf_actual_365(30)
        >>> print(f"Diferencia: {yf_360 - yf_365:.6f}")
        
    Note:
        - Fórmula: días / 365
        - Estándar en muchos bonos gubernamentales
        - Resulta en fracciones ligeramente menores que Actual/360
    """
    return plazo / 365


def calculo_yf_30_360(fecha_ini: Union[datetime.datetime, pd.Series, np.ndarray],
                      fecha_fin: Union[datetime.datetime, pd.Series, np.ndarray]
                      ) -> Union[float, pd.Series, np.ndarray]:
    """
    Calcula la fracción de año usando la convención 30/360.
    
    Esta convención asume que cada mes tiene exactamente 30 días y el año 360 días.
    Es ampliamente utilizada en bonos corporativos y swaps de tasa de interés.
    Implementa el estándar ISDA 2006.
    
    Args:
        fecha_ini: Fecha de inicio del período. Puede ser datetime, Series o array de fechas
        fecha_fin: Fecha de fin del período. Puede ser datetime, Series o array de fechas
        
    Returns:
        Fracción de año según convención 30/360. El tipo depende del tipo de entrada.
        
    Raises:
        ValueError: Si las fechas no son válidas o están en formato incorrecto
        
    Example:
        >>> from datetime import datetime
        >>> 
        >>> # Ejemplo básico
        >>> inicio = datetime(2023, 1, 15)
        >>> fin = datetime(2023, 4, 15)
        >>> yf = calculo_yf_30_360(inicio, fin)
        >>> print(f"YF 30/360: {yf:.6f}")  # 0.25 (exactamente 3 meses)
        >>> 
        >>> # Con pandas Series
        >>> import pandas as pd
        >>> fechas_ini = pd.to_datetime(['2023-01-15', '2023-02-28'])
        >>> fechas_fin = pd.to_datetime(['2023-04-15', '2023-05-30'])
        >>> yf_series = calculo_yf_30_360(fechas_ini, fechas_fin)
        >>> 
        >>> # Comparar con días reales
        >>> dias_reales = (fin - inicio).days
        >>> yf_actual = calculo_yf_actual_365(dias_reales)
        >>> print(f"YF 30/360: {yf:.6f} vs Actual/365: {yf_actual:.6f}")
        
    Note:
        - Fórmula: (360*(Y2-Y1) + 30*(M2-M1) + (D2-D1)) / 360
        - D1 = min(30, día_inicial), D2 = min(D1, día_final) si D1=30, sino día_final
        - Implementa reglas ISDA 2006 para ajuste de días finales de mes
        - Útil para instrumentos que requieren periodicidad exacta
        - Referencia: https://www.isda.org/a/mIJEE/30-360-2006ISDADefs.xls
    """
    # Caso simple: ambas fechas son datetime/timestamp individuales
    if isinstance(fecha_ini, (datetime.datetime, pd.Timestamp)) and \
       isinstance(fecha_fin, (datetime.datetime, pd.Timestamp)):

        d1 = min(30, fecha_ini.day)
        d2 = min(d1, fecha_fin.day) if d1 == 30 else fecha_fin.day

        return (360 * (fecha_fin.year - fecha_ini.year) + 
                30 * (fecha_fin.month - fecha_ini.month) + 
                d2 - d1) / 360

    # Convertir a datetime si no lo son ya
    fecha_ini = pd.to_datetime(fecha_ini)
    fecha_fin = pd.to_datetime(fecha_fin)

    # Manejar casos donde una fecha es escalar y otra es serie
    if isinstance(fecha_ini, (datetime.datetime, pd.Timestamp)):
        fecha_ini = pd.Series([fecha_ini] * len(fecha_fin), index=fecha_fin.index)
    if isinstance(fecha_fin, (datetime.datetime, pd.Timestamp)):
        fecha_fin = pd.Series([fecha_fin] * len(fecha_ini), index=fecha_ini.index)

    # Asegurar que ambas son Series
    if not isinstance(fecha_ini, pd.Series):
        fecha_ini = pd.Series(fecha_ini)
    if not isinstance(fecha_fin, pd.Series):
        fecha_fin = pd.Series(fecha_fin)

    # Aplicar reglas 30/360 ISDA
    d1 = np.minimum(30, fecha_ini.dt.day)
    d2 = np.where(d1 == 30, np.minimum(d1, fecha_fin.dt.day), fecha_fin.dt.day)

    return (360 * (fecha_fin.dt.year - fecha_ini.dt.year) +
            30 * (fecha_fin.dt.month - fecha_ini.dt.month) +
            d2 - d1) / 360

# ============================================================================
# FUNCIONES DE CÁLCULO DE FACTOR DE DESCUENTO (DISCOUNT FACTOR)
# ============================================================================

def calculo_fd_lineal(tasa: Union[int, float, pd.Series, np.ndarray],
                      yf: Union[int, float, pd.Series, np.ndarray]
                      ) -> Union[float, pd.Series, np.ndarray]:
    """
    Calcula el factor de descuento usando capitalización simple (lineal).
    
    El factor de descuento lineal se utiliza principalmente para plazos cortos
    donde la capitalización compuesta no es estándar de mercado.
    
    Args:
        tasa: Tasa de interés en formato decimal (ej: 0.05 para 5%)
        yf: Fracción de año (year fraction) calculada con alguna convención
        
    Returns:
        Factor de descuento. El tipo de retorno coincide con el tipo de entrada.
        
    Example:
        >>> # Factor de descuento para 3 meses al 5%
        >>> tasa = 0.05
        >>> yf = calculo_yf_actual_360(90)  # 90 días
        >>> fd = calculo_fd_lineal(tasa, yf)
        >>> print(f"Factor de descuento lineal: {fd:.6f}")
        >>> 
        >>> # Valor presente de $1000
        >>> vp = 1000 * fd
        >>> print(f"Valor presente: ${vp:.2f}")
        >>> 
        >>> # Con arrays para múltiples cálculos
        >>> import numpy as np
        >>> tasas = np.array([0.03, 0.04, 0.05])
        >>> yfs = np.array([0.25, 0.5, 1.0])
        >>> fds = calculo_fd_lineal(tasas, yfs)
        
    Note:
        - Fórmula: 1 / (1 + tasa × yf)
        - Usado típicamente para plazos menores a 1 año
        - Común en mercados monetarios y depósitos a plazo corto
        - No considera capitalización de intereses
    """
    return 1 / (1 + tasa * yf)


def calculo_fd_compuesto(tasa: Union[int, float, pd.Series, np.ndarray],
                         yf: Union[int, float, pd.Series, np.ndarray]
                         ) -> Union[float, pd.Series, np.ndarray]:
    """
    Calcula el factor de descuento usando capitalización compuesta.
    
    El factor de descuento compuesto es el estándar para la mayoría de
    instrumentos financieros de largo plazo y valoración de bonos.
    
    Args:
        tasa: Tasa de interés en formato decimal (ej: 0.05 para 5%)
        yf: Fracción de año (year fraction) calculada con alguna convención
        
    Returns:
        Factor de descuento. El tipo de retorno coincide con el tipo de entrada.
        
    Example:
        >>> # Factor de descuento compuesto para 1 año al 5%
        >>> tasa = 0.05
        >>> yf = 1.0
        >>> fd = calculo_fd_compuesto(tasa, yf)
        >>> print(f"Factor de descuento compuesto: {fd:.6f}")  # 0.952381
        >>> 
        >>> # Comparar con descuento lineal
        >>> fd_lineal = calculo_fd_lineal(tasa, yf)
        >>> print(f"Lineal: {fd_lineal:.6f}, Compuesto: {fd:.6f}")
        >>> 
        >>> # Para múltiples plazos
        >>> import pandas as pd
        >>> yfs = pd.Series([0.25, 0.5, 1.0, 2.0, 5.0])
        >>> fds = calculo_fd_compuesto(0.05, yfs)
        >>> print("Factores de descuento por plazo:")
        >>> print(pd.DataFrame({'Plazo': yfs, 'FD': fds}))
        
    Note:
        - Fórmula: 1 / (1 + tasa)^yf
        - Estándar para bonos, swaps y derivados
        - Refleja capitalización de intereses sobre intereses
        - Produce valores menores que descuento lineal para tasas positivas
    """
    return 1 / np.power((1 + tasa), yf)


def calculo_fd_exponencial(tasa: Union[int, float, pd.Series, np.ndarray],
                           yf: Union[int, float, pd.Series, np.ndarray]
                           ) -> Union[float, pd.Series, np.ndarray]:
    """
    Calcula el factor de descuento usando capitalización continua (exponencial).
    
    La capitalización continua asume que los intereses se capitalizan
    instantáneamente. Es común en modelos matemáticos y derivados complejos.
    
    Args:
        tasa: Tasa de interés continua en formato decimal (ej: 0.05 para 5%)
        yf: Fracción de año (year fraction) calculada con alguna convención
        
    Returns:
        Factor de descuento. El tipo de retorno coincide con el tipo de entrada.
        
    Example:
        >>> import math
        >>> 
        >>> # Factor de descuento continuo para 1 año al 5%
        >>> tasa = 0.05
        >>> yf = 1.0
        >>> fd = calculo_fd_exponencial(tasa, yf)
        >>> print(f"Factor de descuento continuo: {fd:.6f}")  # 0.951229
        >>> 
        >>> # Comparar los tres métodos
        >>> fd_lineal = calculo_fd_lineal(tasa, yf)
        >>> fd_compuesto = calculo_fd_compuesto(tasa, yf)
        >>> fd_continuo = calculo_fd_exponencial(tasa, yf)
        >>> 
        >>> print(f"Lineal:    {fd_lineal:.6f}")
        >>> print(f"Compuesto: {fd_compuesto:.6f}")
        >>> print(f"Continuo:  {fd_continuo:.6f}")
        >>> 
        >>> # Para modelado de volatilidad
        >>> import numpy as np
        >>> tiempos = np.array([0.25, 0.5, 1.0, 2.0])
        >>> fds_continuos = calculo_fd_exponencial(0.05, tiempos)
        
    Note:
        - Fórmula: 1 / e^(tasa × yf) = e^(-tasa × yf)
        - Usado en modelos de Black-Scholes y pricing de opciones
        - Matemáticamente más elegante para cálculos analíticos
        - Produce el factor de descuento más pequeño para tasas positivas
        - La tasa debe estar en términos continuos, no discretos
    """
    return 1 / np.exp(tasa * yf)


# ============================================================================
# FUNCIONES DE CÁLCULO DE TASAS DESDE FACTORES DE DESCUENTO
# ============================================================================

def calculo_tasa_lineal_desde_fd(fd: Union[int, float, pd.Series, np.ndarray],
                                 yf: Union[int, float, pd.Series, np.ndarray]
                                 ) -> Union[float, pd.Series, np.ndarray]:
    """
    Calcula la tasa de interés simple desde un factor de descuento.
    
    Función inversa de calculo_fd_lineal(), útil para extraer tasas implícitas
    de precios de mercado bajo capitalización simple.
    
    Args:
        fd: Factor de descuento (debe ser > 0 y ≤ 1 para tasas positivas)
        yf: Fracción de año (year fraction) correspondiente
        
    Returns:
        Tasa de interés en formato decimal. El tipo coincide con el de entrada.
        
    Raises:
        ValueError: Si fd <= 0 o yf = 0
        
    Example:
        >>> # Extraer tasa desde factor de descuento
        >>> fd = 0.975  # Factor de descuento observado
        >>> yf = calculo_yf_actual_360(90)  # 90 días
        >>> tasa = calculo_tasa_lineal_desde_fd(fd, yf)
        >>> print(f"Tasa implícita: {tasa:.4f} ({tasa*100:.2f}%)")
        >>> 
        >>> # Verificar cálculo inverso
        >>> fd_calculado = calculo_fd_lineal(tasa, yf)
        >>> print(f"FD original: {fd}, FD calculado: {fd_calculado:.6f}")
        >>> 
        >>> # Con arrays para curva de tasas
        >>> import numpy as np
        >>> fds_mercado = np.array([0.99, 0.975, 0.95, 0.90])
        >>> yfs = np.array([0.25, 0.5, 1.0, 2.0])
        >>> tasas = calculo_tasa_lineal_desde_fd(fds_mercado, yfs)
        >>> print("Tasas extraídas:", tasas)
        
    Note:
        - Fórmula: ((1/fd) - 1) / yf
        - Función inversa exacta de calculo_fd_lineal()
        - Útil para construcción de curvas de rendimiento
        - fd > 1 implicaría tasas negativas
    """
    return ((1 / fd) - 1) / yf


def calculo_tasa_compuesta_desde_fd(fd: Union[int, float, pd.Series, np.ndarray],
                                    yf: Union[int, float, pd.Series, np.ndarray]
                                    ) -> Union[float, pd.Series, np.ndarray]:
    """
    Calcula la tasa de interés compuesta desde un factor de descuento.
    
    Función inversa de calculo_fd_compuesto(), estándar para extraer tasas
    de bonos, swaps y otros instrumentos con capitalización compuesta.
    
    Args:
        fd: Factor de descuento (debe ser > 0 y ≤ 1 para tasas positivas)
        yf: Fracción de año (year fraction) correspondiente
        
    Returns:
        Tasa de interés en formato decimal. El tipo coincide con el de entrada.
        
    Raises:
        ValueError: Si fd <= 0 o yf = 0
        
    Example:
        >>> # Extraer yield de un bono
        >>> precio_bono = 95.24  # Precio por cada 100 de valor nominal
        >>> fd = precio_bono / 100  # Factor de descuento implícito
        >>> yf = 2.0  # Plazo de 2 años
        >>> yield_bono = calculo_tasa_compuesta_desde_fd(fd, yf)
        >>> print(f"Yield del bono: {yield_bono:.4f} ({yield_bono*100:.2f}%)")
        >>> 
        >>> # Verificar cálculo inverso
        >>> fd_calculado = calculo_fd_compuesto(yield_bono, yf)
        >>> print(f"FD original: {fd:.6f}, FD calculado: {fd_calculado:.6f}")
        >>> 
        >>> # Para construcción de curva de rendimiento
        >>> import pandas as pd
        >>> data = {
        ...     'Plazo': [0.5, 1.0, 2.0, 5.0, 10.0],
        ...     'FD': [0.975, 0.952, 0.906, 0.784, 0.614]
        ... }
        >>> df = pd.DataFrame(data)
        >>> df['Tasa'] = calculo_tasa_compuesta_desde_fd(df['FD'], df['Plazo'])
        >>> print(df)
        
    Note:
        - Fórmula: (1/fd)^(1/yf) - 1
        - Función inversa exacta de calculo_fd_compuesto()
        - Estándar para valoración de bonos y construcción de curvas
        - También conocida como tasa spot o tasa cero cupón
    """
    return np.power(1 / fd, 1 / yf) - 1


def calculo_tasa_exponencial_desde_fd(fd: Union[int, float, pd.Series, np.ndarray],
                                      yf: Union[int, float, pd.Series, np.ndarray]
                                      ) -> Union[float, pd.Series, np.ndarray]:
    """
    Calcula la tasa de interés continua desde un factor de descuento.
    
    Función inversa de calculo_fd_exponencial(), utilizada en modelos
    matemáticos avanzados y pricing de derivados complejos.
    
    Args:
        fd: Factor de descuento (debe ser > 0 y ≤ 1 para tasas positivas)
        yf: Fracción de año (year fraction) correspondiente
        
    Returns:
        Tasa continua en formato decimal. El tipo coincide con el de entrada.
        
    Raises:
        ValueError: Si fd <= 0 o yf = 0
        
    Example:
        >>> import math
        >>> 
        >>> # Extraer tasa continua desde FD
        >>> fd = 0.9512  # Factor de descuento observado
        >>> yf = 1.0     # 1 año
        >>> tasa_continua = calculo_tasa_exponencial_desde_fd(fd, yf)
        >>> print(f"Tasa continua: {tasa_continua:.4f} ({tasa_continua*100:.2f}%)")
        >>> 
        >>> # Verificar cálculo inverso
        >>> fd_calculado = calculo_fd_exponencial(tasa_continua, yf)
        >>> print(f"FD original: {fd}, FD calculado: {fd_calculado:.6f}")
        >>> 
        >>> # Conversión entre tasas discretas y continuas
        >>> tasa_discreta = calculo_tasa_compuesta_desde_fd(fd, yf)
        >>> print(f"Tasa discreta: {tasa_discreta:.4f}")
        >>> print(f"Tasa continua: {tasa_continua:.4f}")
        >>> print(f"Diferencia: {abs(tasa_continua - tasa_discreta):.6f}")
        >>> 
        >>> # Para modelos de Black-Scholes
        >>> import numpy as np
        >>> fds_opciones = np.array([0.99, 0.975, 0.95])
        >>> plazos_expiry = np.array([0.25, 0.5, 1.0])
        >>> tasas_libres_riesgo = calculo_tasa_exponencial_desde_fd(fds_opciones, plazos_expiry)
        
    Note:
        - Fórmula: ln(1/fd) / yf = -ln(fd) / yf
        - Función inversa exacta de calculo_fd_exponencial()
        - Fundamental en modelos de Black-Scholes y Merton
        - La tasa resultante es para capitalización continua
        - Para convertir a tasa discreta: e^(r_continua) - 1
    """
    return np.log(1 / fd) / yf