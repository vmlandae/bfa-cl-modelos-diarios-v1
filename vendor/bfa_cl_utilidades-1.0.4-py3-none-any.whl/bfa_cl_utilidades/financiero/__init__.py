"""
Módulo de funciones financieras y matemáticas.

Contiene funciones especializadas para cálculos financieros, interpolaciones,
year fractions, factores de descuento y tasas de interés.
"""

from .financiero_general import (
    # Interpolaciones
    lin_interpol,
    loglin_interpol,
    
    # Funciones financieras generales
    calculo_plazo_medio_permanencia,
    calculo_tasa_forward,
    
    # Year fractions
    calculo_yf_actual_360,
    calculo_yf_actual_365,
    calculo_yf_30_360,
    
    # Factores de descuento
    calculo_fd_lineal,
    calculo_fd_compuesto,
    calculo_fd_exponencial,
    
    # Tasas desde factores de descuento
    calculo_tasa_lineal_desde_fd,
    calculo_tasa_compuesta_desde_fd,
    calculo_tasa_exponencial_desde_fd,
)

__all__ = [
    # Interpolaciones
    "lin_interpol",
    "loglin_interpol",
    
    # Funciones financieras generales
    "calculo_plazo_medio_permanencia",
    "calculo_tasa_forward",
    
    # Year fractions
    "calculo_yf_actual_360",
    "calculo_yf_actual_365",
    "calculo_yf_30_360",
    
    # Factores de descuento
    "calculo_fd_lineal",
    "calculo_fd_compuesto",
    "calculo_fd_exponencial",
    
    # Tasas desde factores de descuento
    "calculo_tasa_lineal_desde_fd",
    "calculo_tasa_compuesta_desde_fd",
    "calculo_tasa_exponencial_desde_fd",
]