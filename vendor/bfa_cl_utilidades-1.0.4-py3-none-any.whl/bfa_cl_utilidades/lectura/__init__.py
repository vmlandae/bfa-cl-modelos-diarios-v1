"""
Módulo de lectura de datos.

Contiene funciones para leer datos desde diversas fuentes como
Microsoft Access, Google BigQuery y conexiones ODBC.

Clases disponibles:
- LectorBigQuery: Clase principal para conectar y leer datos de BigQuery

Funciones de retrocompatibilidad:
- lectura_datos_bigquery: Lee datos usando cuenta de servicio
- lectura_datos_bigquery_odbc: Lee datos usando conexión ODBC  
- lectura_curvas_cero_bigquery: Lee curvas cero específicas
- lectura_tcrc_bigquery: Lee tipos de cambio TCRC

Para nuevos desarrollos, se recomienda usar directamente la clase LectorBigQuery.
"""

from .lectura_archivos_y_rutas import (
    lectura_datos_ms_access,
    lectura_datos_bigquery,
    lectura_datos_bigquery_odbc,
    lectura_curvas_cero_bigquery,
    lectura_tcrc_bigquery,
    LectorBigQuery,
)

__all__ = [
    "lectura_datos_ms_access",
    "lectura_datos_bigquery", 
    "lectura_datos_bigquery_odbc",
    "lectura_curvas_cero_bigquery",
    "lectura_tcrc_bigquery",
    "LectorBigQuery",
]