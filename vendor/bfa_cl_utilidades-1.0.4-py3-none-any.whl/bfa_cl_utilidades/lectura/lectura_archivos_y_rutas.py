import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL
import pyodbc
from google.cloud import bigquery, bigquery_storage
from google.oauth2 import service_account
import warnings
from typing import Literal
import datetime


# ============================================================================
# CLASE DE LECTURA DE BIGQUERY
# ============================================================================
warnings.filterwarnings('ignore', 
                        category=UserWarning, 
                        module='google.auth._default')
warnings.filterwarnings('ignore', category=UserWarning,
                        message='pandas only supports SQLAlchemy connectable.*')


class LectorBigQuery:
    """
    Clase para leer datos desde Google BigQuery usando diferentes métodos de autenticación.
    
    Soporta tres tipos de conexión:
        - 'adc': Application Default Credentials (credenciales por defecto de gcloud)
        - 'cuenta_servicio': Archivo JSON de cuenta de servicio
        - 'odbc': Conexión ODBC mediante DSN configurado en el sistema
    
    Attributes:
        proyecto_id (str): ID del proyecto de Google Cloud
        tipo_conexion (str): Método de autenticación a usar
        ruta_cuenta_servicio (str): Ruta al archivo JSON de credenciales
        connection_string (str): Cadena de conexión ODBC
        _credenciales: Objeto de credenciales (uso interno)
    
    Example:
        >>> # Usando ADC (Application Default Credentials)
        >>> lector = LectorBigQuery(tipo_conexion='adc', proyecto_id='mi-proyecto')
        >>> df = lector.leer_a_dataframe("SELECT * FROM `dataset.tabla`")
        
        >>> # Usando cuenta de servicio
        >>> lector = LectorBigQuery(
        ...     tipo_conexion='cuenta_servicio',
        ...     proyecto_id='mi-proyecto',
        ...     archivo_credenciales_json='ruta/a/credenciales.json'
        ... )
        
        >>> # Usando ODBC
        >>> lector = LectorBigQuery(tipo_conexion='odbc', proyecto_id='mi-dsn')
    """
    
    def __init__(self,
                 tipo_conexion: Literal['adc', 'cuenta_servicio', 'odbc'],
                 proyecto_id: str = None,
                 archivo_credenciales_json: str = None,
                 connection_string: str = None):
        """
        Inicializa el lector de BigQuery.
        
        Args:
            tipo_conexion: Tipo de autenticación. Valores válidos:
                - 'adc': Usa credenciales por defecto de Google Cloud SDK
                - 'cuenta_servicio': Usa archivo JSON de cuenta de servicio
                - 'odbc': Usa conexión ODBC con DSN configurado
            proyecto_id: ID del proyecto de GCP. Para ODBC, se usa como nombre del DSN
                        si no se proporciona connection_string
            archivo_credenciales_json: Ruta al archivo JSON de la cuenta de servicio.
                                      Requerido solo si tipo_conexion='cuenta_servicio'
            connection_string: Cadena de conexión ODBC completa (opcional).
                              Si no se proporciona, se construye usando proyecto_id como DSN
        """
        self.proyecto_id = proyecto_id
        self.tipo_conexion = tipo_conexion
        self.ruta_cuenta_servicio = archivo_credenciales_json
        self.connection_string = connection_string
        self._credenciales = None  # Almacena credenciales para reutilizar en Storage API

    def _crear_cliente(self) -> bigquery.Client:
        """
        Crea y retorna un cliente de BigQuery según el tipo de conexión configurado.
        
        Returns:
            bigquery.Client: Cliente autenticado de BigQuery.
            None: Si el tipo de conexión es 'odbc' (no usa cliente BigQuery).
        
        Raises:
            ValueError: Si tipo_conexion='cuenta_servicio' y no se proporcionó
                       archivo de credenciales.
        """
        # Conexión usando Application Default Credentials (gcloud auth)
        if self.tipo_conexion == 'adc':
            return bigquery.Client(project=self.proyecto_id)
        
        # Conexión usando archivo JSON de cuenta de servicio
        if self.tipo_conexion == 'cuenta_servicio':
            if not self.ruta_cuenta_servicio:
                raise ValueError("Falta ruta_cuenta_servicio para tipo_conexion 'cuenta_servicio'")
            # Guardar credenciales para usarlas también en BigQueryReadClient
            self._credenciales = service_account.Credentials.from_service_account_file(
                self.ruta_cuenta_servicio
            )
            return bigquery.Client(credentials=self._credenciales, project=self.proyecto_id)
        
        # ODBC no requiere cliente de BigQuery
        if self.tipo_conexion == 'odbc':
            return None

    def _leer_odbc(self, query: str) -> pd.DataFrame:
        """
        Lee datos de BigQuery usando conexión ODBC.
        
        Requiere que el driver ODBC de BigQuery esté instalado y configurado.
        Si no se proporcionó connection_string, construye una usando proyecto_id como DSN.
        
        Args:
            query: Consulta SQL a ejecutar.
        
        Returns:
            pd.DataFrame: Resultados de la consulta.
        
        Raises:
            ConnectionError: Si hay error de conexión ODBC.
            RuntimeError: Si hay error ejecutando la consulta.
        """
        # Construir connection_string si no fue proporcionado
        if not self.connection_string and self.proyecto_id is None:
            raise ValueError("Falta proyecto_id para construir connection_string ODBC")

        if not self.connection_string:
            DSN_NAME = self.proyecto_id # Usar proyecto_id como DSN, debe ser cofigurado previamente
            self.connection_string = f"DSN={DSN_NAME};OAuthMechanism=1;"
        
        try:
            with pyodbc.connect(self.connection_string, autocommit=True) as cnxn:
                df = pd.read_sql_query(query, cnxn)
            return df
        except pyodbc.Error as e:
            raise ConnectionError(f"Error de conexión ODBC: {e}")
        except Exception as e:
            raise RuntimeError(f"Error ejecutando consulta: {e}")

    def leer_a_dataframe(self, query: str) -> pd.DataFrame:
        """
        Ejecuta una consulta SQL y retorna los resultados como DataFrame.
        
        Método estándar de lectura. Para datasets grandes, considerar usar
        leer_a_dataframe_optmizado() que utiliza la Storage API (más rápido).
        
        Args:
            query: Consulta SQL estándar de BigQuery a ejecutar.
        
        Returns:
            pd.DataFrame: DataFrame con los resultados de la consulta.
        
        Example:
            >>> lector = LectorBigQuery(tipo_conexion='adc', proyecto_id='mi-proyecto')
            >>> df = lector.leer_a_dataframe("SELECT * FROM `dataset.tabla` LIMIT 100")
        """
        # Redirigir a método ODBC si corresponde
        if self.tipo_conexion == 'odbc':
            return self._leer_odbc(query)
        
        # Usar cliente de BigQuery para ADC o cuenta de servicio
        client = self._crear_cliente()
        df = client.query(query).to_dataframe()
        return df

    def leer_a_dataframe_optmizado(self, query: str) -> pd.DataFrame:
        """
        Lee datos de BigQuery usando la Storage API para mejor rendimiento.
        
        La Storage API (BigQuery Read API) es más eficiente para descargar
        grandes volúmenes de datos. Usa streaming paralelo y formato Arrow
        para transferencias más rápidas.
        
        Note:
            - Este método NO está disponible para conexiones ODBC.
            - Para datasets pequeños, la diferencia de rendimiento es mínima.
            - Requiere permisos adicionales de BigQuery Storage API.
        
        Args:
            query: Consulta SQL estándar de BigQuery a ejecutar.
        
        Returns:
            pd.DataFrame: DataFrame con los resultados de la consulta.
        
        Raises:
            NotImplementedError: Si se usa con tipo_conexion='odbc'.
        
        Example:
            >>> lector = LectorBigQuery(tipo_conexion='adc', proyecto_id='mi-proyecto')
            >>> # Recomendado para consultas con muchos registros
            >>> df = lector.leer_a_dataframe_optmizado(
            ...     "SELECT * FROM `dataset.tabla_grande`"
            ... )
        """
        # Validar que no sea conexión ODBC
        if self.tipo_conexion == 'odbc':
            raise NotImplementedError(
                "El método 'leer_a_dataframe_optmizado' no está disponible para conexiones ODBC. "
                "Use 'leer_a_dataframe()' en su lugar."
            )
        
        # Crear cliente de BigQuery
        client = self._crear_cliente()
        
        # Crear cliente de Storage API con las mismas credenciales
        # IMPORTANTE: Usar las mismas credenciales evita error de permisos
        if self.tipo_conexion == 'cuenta_servicio' and self._credenciales:
            bq_storage_client = bigquery_storage.BigQueryReadClient(
                credentials=self._credenciales
            )
        elif self.tipo_conexion == 'adc':
            bq_storage_client = bigquery_storage.BigQueryReadClient()
        
        # Ejecutar consulta y convertir a DataFrame usando Storage API
        df = client.query(query).to_dataframe(bqstorage_client=bq_storage_client)
        return df

    def lectura_curvas_cero(self, 
                        fechas: list | str | datetime.date | datetime.datetime | pd.Timestamp, 
                        curvas: list | None = None,
                        optimizado: bool = False) -> pd.DataFrame:
        """
        Lee curvas cero desde BigQuery para fechas y curvas específicas.
        
        Consulta la tabla de valorización para obtener datos de curvas tipo 'CERO'.
        
        Args:
            fechas: Lista de fechas o una fecha individual. Acepta:
                - list: ['2025-01-15', '2025-01-16'] o [datetime.date(2025,1,15), ...]
                - str: '2025-01-15'
                - datetime.date: date(2025, 1, 15)
                - datetime.datetime: datetime(2025, 1, 15, 10, 30)
                - pd.Timestamp: Timestamp('2025-01-15')
            curvas: Lista de curvas/instrumentos a filtrar. Si es None, trae todas las curvas
            optimizado: Si True, usa leer_a_dataframe_optmizado() para mejor rendimiento.
                    Solo disponible para conexiones 'adc' y 'cuenta_servicio'
        
        Returns:
            pd.DataFrame: DataFrame con los datos de curvas cero
        
        Raises:
            ValueError: Si las fechas son None o vacías
            NotImplementedError: Si optimizado=True y tipo_conexion='odbc'
        
        Example:
            >>> # Usando fecha individual como string
            >>> lector = LectorBigQuery(tipo_conexion='adc', proyecto_id='mi-proyecto')
            >>> df = lector.lectura_curvas_cero(fechas='2025-01-15')
            >>> 
            >>> # Usando datetime.date individual
            >>> from datetime import date
            >>> df = lector.lectura_curvas_cero(fechas=date(2025, 1, 15))
            >>> 
            >>> # Usando lista de fechas mixta
            >>> from datetime import datetime, date
            >>> df = lector.lectura_curvas_cero(
            ...     fechas=[date(2025, 1, 15), '2025-01-16', datetime(2025, 1, 17)],
            ...     curvas=['COSTO FONDO CLP', 'CURVA_UF'],
            ...     optimizado=True
            ... )
        """
        # Validar entrada de fechas
        if fechas is None:
            raise ValueError("El parámetro 'fechas' no puede ser None")
        
        if not isinstance(fechas, list):
            fechas = [fechas]
            
        # Validar que la lista no esté vacía
        if len(fechas) == 0:
            raise ValueError("La lista de fechas no puede estar vacía")
        
        # Validar uso de optimización con ODBC
        if optimizado and self.tipo_conexion == 'odbc':
            raise NotImplementedError(
                "El parámetro 'optimizado=True' no está disponible para conexiones ODBC. "
                "Use 'optimizado=False' en su lugar."
            )
        
        # Convertir todas las fechas a string
        fechas_convertidas = []
        for fecha in fechas:
            if isinstance(fecha, str):
                fechas_convertidas.append(fecha)
            else:
                # Maneja datetime.datetime, datetime.date, pd.Timestamp
                fechas_convertidas.append(fecha.strftime('%Y-%m-%d'))
        
        # Formatear fechas para la consulta SQL
        fechas_str = ', '.join([f"'{fecha}'" for fecha in fechas_convertidas])
        
        # Construir filtro de curvas si se especifica
        filtro_curvas = ""
        if curvas is not None and len(curvas) > 0:
            curvas_str = ', '.join([f"'{curva}'" for curva in curvas])
            filtro_curvas = f"AND INSTRUMENTO IN ({curvas_str})"
        
        # Construir consulta SQL
        query = f"""
        SELECT
            FECHA,
            INSTRUMENTO,
            MONEDA,
            COMPOSICION,
            BASE,
            TIPO,
            NEMOTECNICO,
            PLAZO_INI,
            PLAZO_FIN,
            TASA_MID,
            PRECIO_MID
        FROM `bfa-cl-trade-price-report-prd.trf_bfa_cl_valorizacion_prd.trf_valorizacion_precios_dia`
        WHERE 1=1 
            AND FechaCarga IN ({fechas_str})
            AND TIPO in ('CERO')
            {filtro_curvas}
        ORDER BY
            PLAZO_INI ASC
        """
        
        # Ejecutar consulta usando los métodos de la clase
        if optimizado:
            return self.leer_a_dataframe_optmizado(query)
        else:
            return self.leer_a_dataframe(query)

    def lectura_tcrc(self, 
                    fechas: list | str | datetime.date | datetime.datetime | pd.Timestamp,
                    moneda: list | None = None,
                    optimizado: bool = False) -> pd.DataFrame:
        """
        Lee tipos de cambio de representacion contable (TCRC) desde BigQuery para fechas y monedas específicas.
        
        Consulta la tabla de valorización para obtener datos de tipos de cambio TCRC
        de origen 'INGESTA'.
        
        Args:
            fechas: Lista de fechas O una fecha individual. Acepta:
                - list: ['2025-01-15', '2025-01-16'] o [datetime.date(2025,1,15), ...]
                - str: '2025-01-15'
                - datetime.date: date(2025, 1, 15)
                - datetime.datetime: datetime(2025, 1, 15, 10, 30)
                - pd.Timestamp: Timestamp('2025-01-15')
            moneda: Lista de monedas a filtrar (ej: ['USD', 'EUR']). 
                Si es None, trae todas las monedas disponibles
            optimizado: Si True, usa leer_a_dataframe_optmizado() para mejor rendimiento.
                    Solo disponible para conexiones 'adc' y 'cuenta_servicio'
        
        Returns:
            pd.DataFrame: DataFrame con columnas [FECHA, INSTRUMENTO, MONEDA, BASE, PRECIO_MID]
            
        Raises:
            ValueError: Si las fechas son None o vacías
            NotImplementedError: Si optimizado=True y tipo_conexion='odbc'
        
        Example:
            >>> # Usando fecha individual y monedas específicas
            >>> lector = LectorBigQuery(tipo_conexion='adc', proyecto_id='mi-proyecto')
            >>> df = lector.lectura_tcrc(
            ...     fechas='2025-01-15',
            ...     moneda=['USD', 'EUR']
            ... )
            >>> 
            >>> # Usando lista de fechas y todas las monedas
            >>> from datetime import date
            >>> df = lector.lectura_tcrc(
            ...     fechas=[date(2025, 1, 15), '2025-01-16'],
            ...     optimizado=True
            ... )
            >>> 
            >>> # Usando conexión ODBC
            >>> lector_odbc = LectorBigQuery(tipo_conexion='odbc', proyecto_id='mi-dsn')
            >>> df = lector_odbc.lectura_tcrc(
            ...     fechas=['2025-01-15'],
            ...     moneda=['USD', 'CLP']
            ... )
        """
        # Validar entrada de fechas
        if fechas is None:
            raise ValueError("El parámetro 'fechas' no puede ser None")
        
        # Convertir fecha individual a lista
        if not isinstance(fechas, list):
            fechas = [fechas]
        
        # Validar que la lista no esté vacía
        if len(fechas) == 0:
            raise ValueError("La lista de fechas no puede estar vacía")
        
        # Validar uso de optimización con ODBC
        if optimizado and self.tipo_conexion == 'odbc':
            raise NotImplementedError(
                "El parámetro 'optimizado=True' no está disponible para conexiones ODBC. "
                "Use 'optimizado=False' en su lugar."
            )
        
        # Convertir todas las fechas a string
        fechas_convertidas = []
        for fecha in fechas:
            if isinstance(fecha, str):
                fechas_convertidas.append(fecha)
            else:
                # Maneja datetime.datetime, datetime.date, pd.Timestamp
                fechas_convertidas.append(fecha.strftime('%Y-%m-%d'))
        
        # Formatear fechas para la consulta SQL
        fechas_str = ', '.join([f"'{fecha}'" for fecha in fechas_convertidas])
        
        # Construir filtro de moneda si se especifica
        filtro_moneda = ""
        if moneda is not None and len(moneda) > 0:
            moneda_str = ', '.join([f"'{m}'" for m in moneda])
            filtro_moneda = f"AND MONEDA IN ({moneda_str})"
        
        # Construir consulta SQL
        query = f"""
        SELECT
            FECHA,
            INSTRUMENTO,
            MONEDA,
            BASE,
            PRECIO_MID
        FROM `bfa-cl-trade-price-report-prd.trf_bfa_cl_valorizacion_prd.trf_valorizacion_precios_dia`
        WHERE 1=1 
            AND FechaCarga IN ({fechas_str})
            AND INSTRUMENTO IN ('TCRC')
            {filtro_moneda}
            AND ORIGEN = 'INGESTA'
        """
        
        # Ejecutar consulta usando los métodos de la clase
        if optimizado:
            return self.leer_a_dataframe_optmizado(query)
        else:
            return self.leer_a_dataframe(query)




# ============================================================================
# FUNCIONES DE LECTURA DE DATOS
# ============================================================================

def lectura_datos_ms_access(ruta: str, query: str) -> pd.DataFrame:
    """
    Lee datos desde una base de datos Microsoft Access.
    
    Args:
        ruta (str): Ruta completa al archivo de base de datos Access (.mdb o .accdb)
        query (str): Consulta SQL a ejecutar en la base de datos
        
    Returns:
        pd.DataFrame: DataFrame con los resultados de la consulta
        
    Raises:
        Exception: Si hay errores de conexión o en la consulta SQL
        
    Example:
        >>> df = lectura_datos_ms_access(
        ...     ruta=r"C:\datos\mi_base.accdb",
        ...     query="SELECT * FROM tabla_ejemplo"
        ... )
    """
    connection_str = r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};'
    connection_str += f'DBQ={ruta};'

    connection_url = URL.create("access+pyodbc", query={"odbc_connect": connection_str})
    engine = create_engine(connection_url)
    
    try:
        raw_data = pd.read_sql(text(query), con=engine)
        return raw_data
    finally:
        engine.dispose()



# ============================================================================
# FUNCIONES DE RETROCOMPATIBILIDAD
# ============================================================================
def lectura_datos_bigquery(ruta_cuenta_servicio: str, query: str) -> pd.DataFrame:
    """
    Lee datos desde Google BigQuery usando credenciales de cuenta de servicio.
    
    Esta función mantiene retrocompatibilidad. Internamente usa la clase LectorBigQuery.
    Para nuevos desarrollos, considere usar directamente la clase LectorBigQuery.
    
    Args:
        ruta_cuenta_servicio (str): Ruta al archivo JSON con las credenciales 
                                  de la cuenta de servicio de Google Cloud
        query (str): Consulta SQL estándar de BigQuery a ejecutar
        
    Returns:
        pd.DataFrame: DataFrame con los resultados de la consulta
        
    Raises:
        Exception: Si hay errores de autenticación o en la consulta
        
    Example:
        >>> df = lectura_datos_bigquery(
        ...     ruta_cuenta_servicio="credenciales.json",
        ...     query="SELECT * FROM `proyecto.dataset.tabla` LIMIT 100"
        ... )
        
    Note:
        El archivo JSON debe contener las credenciales válidas de una cuenta
        de servicio con permisos de lectura en BigQuery.
    """
    # Usar la clase LectorBigQuery internamente
    lector = LectorBigQuery(
        tipo_conexion='cuenta_servicio',
        archivo_credenciales_json=ruta_cuenta_servicio
    )
    return lector.leer_a_dataframe(query)

def lectura_datos_bigquery_odbc(query: str, connection_string: str) -> pd.DataFrame:
    """
    Lee datos de BigQuery usando conexión ODBC directa con pyodbc.
    
    Esta función mantiene retrocompatibilidad. Internamente usa la clase LectorBigQuery.
    Para nuevos desarrollos, considere usar directamente la clase LectorBigQuery.
    
    Args:
        query (str): Consulta SQL a ejecutar en BigQuery
        connection_string (str): Cadena de conexión ODBC. Debe incluir DSN
                               y mecanismo de autenticación apropiado.

    Returns:
        pd.DataFrame: DataFrame con los resultados de la consulta.
                     None si ocurre un error durante la ejecución.

    Example:
        >>> # Usando DSN configurado
        >>> connection_str = "DSN=bfa_cl_risk_dev;OAuthMechanism=1;"
        >>> df = lectura_datos_bigquery_odbc(
        ...     query="SELECT * FROM `proyecto.dataset.tabla`",
        ...     connection_string=connection_str
        ... )
        >>> 
        >>> # Verificar si la operación fue exitosa
        >>> if df is not None:
        ...     print(f"Se obtuvieron {len(df)} filas")
        
    Note:
        - Requiere driver ODBC de BigQuery instalado y configurado
        - El DSN debe estar configurado en el sistema operativo
        - Para autenticación OAuth, usar OAuthMechanism=1
        - Los errores se capturan y se retorna None para mantener retrocompatibilidad
        
    Raises:
        No lanza excepciones directamente, las captura y retorna None.
    """
    try:
        # Usar la clase LectorBigQuery internamente
        lector = LectorBigQuery(
            tipo_conexion='odbc',
            connection_string=connection_string
        )
        return lector.leer_a_dataframe(query)
    except Exception as e:
        print(f"Error ejecutando consulta: {e}")
        return None

def lectura_curvas_cero_bigquery(fechas: list,
                                tipo_conexion: str,
                                curvas: list | None = None,
                                ruta_cuenta_servicio: str | None = None,
                                connection_string: str | None = None) -> pd.DataFrame:
    """
    Lee curvas cero desde BigQuery usando cuenta de servicio o conexión ODBC.
    
    Esta función mantiene retrocompatibilidad. Internamente usa la clase LectorBigQuery.
    Para nuevos desarrollos, considere usar directamente la clase LectorBigQuery.
    
    Esta función mantiene retrocompatibilidad. Internamente usa la clase LectorBigQuery.
    Para nuevos desarrollos, considere usar directamente la clase LectorBigQuery.
    
    Args:
        fechas (list): Lista de fechas a filtrar. Acepta str, datetime.datetime, 
                      datetime.date o pd.Timestamp
        tipo_conexion (str): Tipo de conexión. Valores: 'servicio' o 'odbc'
        curvas (list, optional): Lista de curvas/instrumentos a filtrar. Si es None, trae todas las curvas
        ruta_cuenta_servicio (str, optional): Ruta al JSON de cuenta de servicio.
                                             Requerido si tipo_conexion='servicio'
        connection_string (str, optional): Cadena de conexión ODBC.
                                          Requerido si tipo_conexion='odbc'
    
    Returns:
        pd.DataFrame: DataFrame con los datos de curvas cero
        
    Raises:
        ValueError: Si tipo_conexion no es válido o faltan parámetros requeridos
        
    Example:
        >>> # Usando cuenta de servicio con curvas específicas
        >>> df = lectura_curvas_cero_bigquery(
        ...     fechas=['2025-01-15', '2025-01-16'],
        ...     tipo_conexion='servicio',
        ...     curvas=['COSTO FONDO CLP', 'CURVA_UF'],
        ...     ruta_cuenta_servicio='credenciales.json'
        ... )
        >>> 
        >>> # Usando conexión ODBC sin filtro de curvas (todas las curvas)
        >>> from datetime import date
        >>> df = lectura_curvas_cero_bigquery(
        ...     fechas=[date(2025, 1, 15), date(2025, 1, 16)],
        ...     tipo_conexion='odbc',
        ...     connection_string='DSN=bfa_cl_risk_dev;OAuthMechanism=1;'
        ... )
    """
    # Validar tipo de conexión
    if tipo_conexion not in ['servicio', 'odbc']:
        raise ValueError("tipo_conexion debe ser 'servicio' o 'odbc'")
    
    # Validar parámetros requeridos según tipo de conexión
    if tipo_conexion == 'servicio' and not ruta_cuenta_servicio:
        raise ValueError("ruta_cuenta_servicio es requerido cuando tipo_conexion='servicio'")
    
    if tipo_conexion == 'odbc' and not connection_string:
        raise ValueError("connection_string es requerido cuando tipo_conexion='odbc'")
    
    
    # Usar la clase LectorBigQuery internamente
    if tipo_conexion == 'servicio':
        lector = LectorBigQuery(
            tipo_conexion='cuenta_servicio',
            archivo_credenciales_json=ruta_cuenta_servicio
        )
    else:  # tipo_conexion == 'odbc'
        lector = LectorBigQuery(
            tipo_conexion='odbc',
            connection_string=connection_string
        )
    
    return lector.lectura_curvas_cero(fechas=fechas, curvas=curvas)

def lectura_tcrc_bigquery(fechas: list,
                                tipo_conexion: str,
                                moneda: list | None = None,
                                ruta_cuenta_servicio: str | None = None,
                                connection_string: str | None = None) -> pd.DataFrame:
    """
    Lee tipos de cambio (TCRC) desde BigQuery usando cuenta de servicio o conexión ODBC.
    
    Esta función mantiene retrocompatibilidad. Internamente usa la clase LectorBigQuery.
    Para nuevos desarrollos, considere usar directamente la clase LectorBigQuery.
    
    Esta función mantiene retrocompatibilidad. Internamente usa la clase LectorBigQuery.
    Para nuevos desarrollos, considere usar directamente la clase LectorBigQuery.
    
    Args:
        fechas (list): Lista de fechas a filtrar. Acepta str, datetime.datetime, 
                      datetime.date o pd.Timestamp
        tipo_conexion (str): Tipo de conexión. Valores: 'servicio' o 'odbc'
        moneda (list, optional): Lista de monedas a filtrar. Si es None, trae todas las monedas
        ruta_cuenta_servicio (str, optional): Ruta al JSON de cuenta de servicio.
                                             Requerido si tipo_conexion='servicio'
        connection_string (str, optional): Cadena de conexión ODBC.
                                          Requerido si tipo_conexion='odbc'
    
    Returns:
        pd.DataFrame: DataFrame con los datos de tipos de cambio
        
    Raises:
        ValueError: Si tipo_conexion no es válido o faltan parámetros requeridos
        
    Example:
        >>> # Con monedas específicas
        >>> df = lectura_tcrc_bigquery(
        ...     fechas=['2025-01-15'],
        ...     tipo_conexion='odbc',
        ...     moneda=['USD', 'EUR'],
        ...     connection_string='DSN=bfa_cl_risk_dev;OAuthMechanism=1;'
        ... )
        >>> 
        >>> # Sin filtro de moneda (todas las monedas)
        >>> df = lectura_tcrc_bigquery(
        ...     fechas=['2025-01-15'],
        ...     tipo_conexion='odbc',
        ...     connection_string='DSN=bfa_cl_risk_dev;OAuthMechanism=1;'
        ... )
    """
    # Validar tipo de conexión
    if tipo_conexion not in ['servicio', 'odbc']:
        raise ValueError("tipo_conexion debe ser 'servicio' o 'odbc'")
    
    # Validar parámetros requeridos según tipo de conexión
    if tipo_conexion == 'servicio' and not ruta_cuenta_servicio:
        raise ValueError("ruta_cuenta_servicio es requerido cuando tipo_conexion='servicio'")
    
    if tipo_conexion == 'odbc' and not connection_string:
        raise ValueError("connection_string es requerido cuando tipo_conexion='odbc'")
    
    if tipo_conexion == 'servicio':
        lector = LectorBigQuery(
            tipo_conexion='cuenta_servicio',
            archivo_credenciales_json=ruta_cuenta_servicio
        )
    else:  # tipo_conexion == 'odbc'
        lector = LectorBigQuery(
            tipo_conexion='odbc',
            connection_string=connection_string
        )
    
    return lector.lectura_tcrc(fechas=fechas, moneda=moneda)