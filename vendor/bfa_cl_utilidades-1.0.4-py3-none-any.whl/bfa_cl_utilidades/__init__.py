"""
bfa_cl_utilidades

Paquete de utilidades especializadas para el sector financiero chileno.
Incluye funciones para conectividad de datos, cálculos financieros,
interpolaciones matemáticas y manejo de fechas laborales.

Módulos disponibles:
- lectura: Funciones para leer datos desde diversas fuentes
- escritura: Funciones para escribir y cargar datos
- financiero: Cálculos financieros e interpolaciones matemáticas  
- otros: Utilidades misceláneas y manejo de fechas

Ejemplo de uso:
    >>> from bfa_cl_utilidades import lectura_datos_bigquery, calculo_tasa_forward
    >>> # Para nuevos desarrollos, usar las clases LectorBigQuery y CargaGCP
    >>> from bfa_cl_utilidades import LectorBigQuery, CargaGCP
    >>> 
    >>> # Lectura de datos
    >>> lector = LectorBigQuery(tipo_conexion='adc', proyecto_id='mi-proyecto')
    >>> df = lector.leer_a_dataframe("SELECT * FROM `dataset.tabla`")
    >>> 
    >>> # Carga de datos
    >>> carga = CargaGCP(tipo_conexion='adc', proyecto_id='mi-proyecto')
    >>> carga.cargar_dataframe_a_bigquery(df, 'dataset', 'tabla', 'TRUNCATE')
    >>> 
    >>> # o importar módulos completos
    >>> from bfa_cl_utilidades import financiero, lectura, escritura
"""


__version__ = "1.0.4"
__author__ = "Metodologias y Modelos - Riesgo Financiero Banco Falabella"
__email__ = ""
__description__ = "Utilidades especializadas para el sector financiero chileno"

# Importaciones desde submódulos para facilitar el uso directo
from .lectura import (
    lectura_datos_ms_access,
    lectura_datos_bigquery,
    lectura_datos_bigquery_odbc,
    lectura_curvas_cero_bigquery,
    lectura_tcrc_bigquery,
    LectorBigQuery,
)

from .escritura import (
    ejecutar_query_bigquery,
    cargar_dataframe_bigquery,
    cargar_datos_ms_access,
    cargar_datos_xlsm,
    CargaGCP,
)

from .financiero import (
    # Interpolaciones
    lin_interpol,
    loglin_interpol,
    
    # Funciones financieras generales
    calculo_plazo_medio_permanencia,
    calculo_tasa_forward,
    
    # Year fractions
    calculo_yf_actual_360,
    calculo_yf_actual_365,
    calculo_yf_30_360,
    
    # Factores de descuento
    calculo_fd_lineal,
    calculo_fd_compuesto,
    calculo_fd_exponencial,
    
    # Tasas desde factores de descuento
    calculo_tasa_lineal_desde_fd,
    calculo_tasa_compuesta_desde_fd,
    calculo_tasa_exponencial_desde_fd,
)

from .otros import (
    # Funciones de fechas
    ultimo_dia_laboral_del_mes,
    ultimo_dia_del_mes,
    agrega_meses_a_fecha,
    agregar_dias_laborales,
    agregar_x_dias_laborales,
    
    # Funciones misceláneas
    estandariza_nombre_columnas_dataframe,
    copia_archivo_en_ruta,
    ejecutar_macro_excel,
    limpiar_hoja_xlsm,
)

# También hacer disponibles los submódulos para importación directa
from . import lectura
from . import escritura
from . import financiero
from . import otros

__all__ = [
    # Metadata
    "__version__",
    "__author__",
    "__email__",
    "__description__",
    
    # Submódulos
    "lectura",
    "escritura", 
    "financiero",
    "otros",
    
    # Funciones de lectura
    "lectura_datos_ms_access",
    "lectura_datos_bigquery",
    "lectura_datos_bigquery_odbc",
    "lectura_curvas_cero_bigquery",
    "lectura_tcrc_bigquery",
    "LectorBigQuery",
    
    # Funciones de escritura
    "CargaGCP",
    "ejecutar_query_bigquery",
    "cargar_dataframe_bigquery",
    "cargar_datos_ms_access",
    "cargar_datos_xlsm",
    
    # Interpolaciones
    "lin_interpol",
    "loglin_interpol",
    
    # Funciones financieras generales
    "calculo_plazo_medio_permanencia",
    "calculo_tasa_forward",
    
    # Year fractions
    "calculo_yf_actual_360",
    "calculo_yf_actual_365",
    "calculo_yf_30_360",
    
    # Factores de descuento
    "calculo_fd_lineal",
    "calculo_fd_compuesto", 
    "calculo_fd_exponencial",
    
    # Tasas desde factores de descuento
    "calculo_tasa_lineal_desde_fd",
    "calculo_tasa_compuesta_desde_fd",
    "calculo_tasa_exponencial_desde_fd",
    
    # Funciones de fechas
    "ultimo_dia_laboral_del_mes",
    "ultimo_dia_del_mes", 
    "agrega_meses_a_fecha",
    "agregar_dias_laborales",
    "agregar_x_dias_laborales",
    
    # Funciones misceláneas
    "estandariza_nombre_columnas_dataframe",
    "copia_archivo_en_ruta",
    "ejecutar_macro_excel",
    "limpiar_hoja_xlsm",
]